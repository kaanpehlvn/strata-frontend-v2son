# Strata Frontend V2

Bu klasör, mevcut `strata-hub` projesinden bağımsız yeni frontend çalışma alanıdır.

## Koruma sınırları

- Mevcut backend, API, veritabanı, worker ve deployment dosyaları bu klasöre taşınmaz veya değiştirilmez.
- `reference/public-site/`, mevcut projenin yerel statik çıktısının yalnızca referans kopyasıdır.
- v0'dan aktarılacak dosyalar bu klasörde hazırlanıp burada doğrulanacaktır.
- API bağlantısı ve ortam değişkenleri v0 çıktısı görüldükten sonra ayrıca tanımlanacaktır; gizli anahtarlar bu klasöre kopyalanmayacaktır.

## Başlangıç yapısı

- `src/`: yeni frontend kaynakları
- `public/`: frontend statik varlıkları
- `reference/public-site/`: mevcut görünüm için salt-okunur referans kopyası

Bu klasör henüz herhangi bir backend'e veya deploy hedefine bağlanmamıştır.
