import { networkInterfaces } from 'node:os'

/** @type {import('next').NextConfig} */
const localDevOrigins = Object.values(networkInterfaces())
  .flat()
  .filter((network) => network?.family === 'IPv4' && !network.internal)
  .map((network) => network.address)

const nextConfig = {
  devIndicators: false,
  // Keep development-only client assets available from the machine's current
  // private-network addresses without trusting arbitrary remote origins.
  allowedDevOrigins: localDevOrigins,
  images: {
    unoptimized: true,
  },
}

export default nextConfig
