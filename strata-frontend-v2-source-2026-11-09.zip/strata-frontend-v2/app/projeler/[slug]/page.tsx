import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { ArrowLeft } from 'lucide-react'
import { ButtonLink, SectionLabel, TextLink } from '@/components/site/primitives'
import { getProject, projects, type StageStatus } from '@/lib/data/projects'
import { cn } from '@/lib/utils'

type Props = { params: Promise<{ slug: string }> }

export function generateStaticParams() {
  return projects.map((p) => ({ slug: p.slug }))
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const project = getProject(slug)
  if (!project) return {}
  return {
    title: project.name,
    description: project.summary,
    alternates: { canonical: `/projeler/${project.slug}` },
  }
}

const statusLabel: Record<StageStatus, string> = {
  done: 'Tamamlandı',
  active: 'Sürüyor',
  planned: 'Planlandı',
}

export default async function ProjectDetailPage({ params }: Props) {
  const { slug } = await params
  const project = getProject(slug)
  if (!project) notFound()

  const index = projects.findIndex((p) => p.slug === slug)
  const next = projects[(index + 1) % projects.length]

  return (
    <>
      <section className="relative flex min-h-[60svh] items-end overflow-hidden bg-graphite pb-14 pt-40 md:pb-20">
        <div aria-hidden="true" className="absolute inset-0 opacity-30 [background-image:linear-gradient(to_right,rgba(245,245,242,.08)_1px,transparent_1px),linear-gradient(to_bottom,rgba(245,245,242,.08)_1px,transparent_1px)] [background-size:clamp(2.5rem,6vw,6rem)_clamp(2.5rem,6vw,6rem)]" />
        <div className="container-x relative">
          <Link
            href="/projeler"
            className="label inline-flex items-center gap-2 text-paper/70 transition-colors hover:text-paper"
          >
            <ArrowLeft aria-hidden="true" className="size-4" />
            Tüm projeler
          </Link>
          <p className="label mt-10 text-signal">
            {project.code} · {project.category} · {project.year}
          </p>
          <h1 className="display mt-4 text-[clamp(4rem,14vw,12rem)]">{project.name}</h1>
          <p className="mt-6 max-w-2xl text-pretty text-xl text-paper/80 md:text-2xl">{project.tagline}</p>
        </div>
      </section>

      <section className="py-20 md:py-28">
        <div className="container-x grid gap-16 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <SectionLabel index="01">Proje hakkında</SectionLabel>
            <div className="mt-8 space-y-6 text-pretty text-lg leading-relaxed text-paper/75">
              {project.description.map((p) => (
                <p key={p}>{p}</p>
              ))}
            </div>
          </div>

          <aside className="lg:col-span-4 lg:col-start-9" aria-label="Teknik özet">
            <dl className="border-t border-paper/20">
              {project.specs.map((s) => (
                <div key={s.label} className="grid grid-cols-[7rem_1fr] gap-4 border-b border-paper/15 py-4">
                  <dt className="label text-paper/50">{s.label}</dt>
                  <dd className="text-paper/90">{s.value}</dd>
                </div>
              ))}
              <div className="grid grid-cols-[7rem_1fr] gap-4 border-b border-paper/15 py-4">
                <dt className="label text-paper/50">Ekip</dt>
                <dd className="text-paper/90">{project.team}</dd>
              </div>
            </dl>
            <ul className="mt-8 flex flex-wrap gap-2" aria-label="Teknolojiler">
              {project.technologies.map((t) => (
                <li key={t} className="label border border-paper/25 px-3 py-2 text-paper/80">
                  {t}
                </li>
              ))}
            </ul>
          </aside>
        </div>
      </section>

      <section className="bg-paper py-20 text-ink md:py-28">
        <div className="container-x">
          <SectionLabel index="02">Geliştirme aşamaları</SectionLabel>
          <ol className="mt-12 grid gap-px bg-ink/15 sm:grid-cols-2 lg:grid-cols-5">
            {project.stages.map((s, i) => (
              <li
                key={s.name}
                className={cn('p-6 md:p-8', s.status === 'active' ? 'bg-ink text-paper' : 'bg-paper')}
              >
                <p className="label flex items-center gap-2">
                  <span
                    aria-hidden="true"
                    className={cn(
                      'size-2',
                      s.status === 'done' && 'bg-ink',
                      s.status === 'active' && 'bg-signal',
                      s.status === 'planned' && 'border border-current opacity-50',
                    )}
                  />
                  {String(i + 1).padStart(2, '0')} · {statusLabel[s.status]}
                </p>
                <h3 className="display mt-8 text-3xl">{s.name}</h3>
                <p className={cn('mt-3 text-pretty leading-relaxed', s.status === 'active' ? 'text-paper/70' : 'text-ink/65')}>
                  {s.note}
                </p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="border-t border-paper/10 py-20 md:py-28">
        <div className="container-x grid gap-10 md:grid-cols-2 md:items-end">
          <div>
            <p className="label text-paper/50">Sonraki proje</p>
            <Link href={`/projeler/${next.slug}`} className="group mt-4 block">
              <span className="display block text-[clamp(3rem,8vw,7rem)] transition-colors duration-500 group-hover:text-signal">
                {next.name}
              </span>
            </Link>
            <p className="mt-3 max-w-md text-paper/65">{next.tagline}</p>
          </div>
          <div className="flex flex-col items-start gap-6 md:items-end">
            <ButtonLink href="/uye-on-kayit">Bu projede çalışmak istiyorum</ButtonLink>
            <TextLink href="/projeler">Tüm projeler</TextLink>
          </div>
        </div>
      </section>
    </>
  )
}
