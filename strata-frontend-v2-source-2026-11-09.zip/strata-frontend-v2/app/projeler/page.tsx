import type { Metadata } from 'next'
import { ProjectsExplorer } from '@/components/projects/projects-explorer'
import { PageHero } from '@/components/site/primitives'

export const metadata: Metadata = {
  title: 'Projeler',
  description: 'STRATA’nın üzerinde düşündüğü iki proje: Çelik Kubbe Hava Savunma Sistemi ve Maglev Treni.',
  alternates: { canonical: '/projeler' },
}

export default function ProjectsPage() {
  return (
    <>
      <PageHero
        label="Projeler"
        title={
          <>
            Soruyu
            <br />
            sisteme dönüştürüyoruz.
          </>
        }
        intro="STRATA’da merakı gerçek dünyadaki sistemlere dönüştürüyoruz. Farklı disiplinleri aynı masada buluşturan proje alanlarımıza göz atın."
      />
      <section className="py-16 md:py-24">
        <div className="container-x">
          <ProjectsExplorer />
        </div>
      </section>
    </>
  )
}
