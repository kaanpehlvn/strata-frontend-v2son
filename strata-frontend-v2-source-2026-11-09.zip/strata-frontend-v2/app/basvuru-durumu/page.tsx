import type { Metadata } from 'next'
import { StatusLookup } from '@/components/forms/status-lookup'
import { PageHero } from '@/components/site/primitives'

export const metadata: Metadata = {
  title: 'Başvuru Durumu',
  description: 'STRATA üyelik başvurunuzun durumunu öğrenci numaranızla sorgulayın.',
  alternates: { canonical: '/basvuru-durumu' },
}

export default function StatusPage() {
  return (
    <>
      <PageHero
        label="Başvuru Durumu"
        title={
          <>
            Başvurum
            <br />
            nerede?
          </>
        }
        intro="Ön kayıt sonrasında size iletilen öğrenci numaranızı girerek başvurunuzun hangi aşamada olduğunu görebilirsiniz."
      />
      <section className="bg-paper py-16 text-ink md:py-24">
        <div className="container-x max-w-5xl">
          <StatusLookup />
        </div>
      </section>
    </>
  )
}
