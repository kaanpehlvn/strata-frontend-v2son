import { ButtonLink } from '@/components/site/primitives'

export default function NotFound() {
  return (
    <section className="flex min-h-[80svh] items-center pt-32">
      <div className="container-x">
        <p className="label text-signal">Hata 404</p>
        <h1 className="display mt-4 text-[clamp(4rem,14vw,12rem)]">
          Sayfa
          <br />
          bulunamadı.
        </h1>
        <p className="mt-6 max-w-md text-pretty text-lg text-paper/70">
          Aradığınız sayfa taşınmış ya da hiç var olmamış olabilir.
        </p>
        <ButtonLink href="/" className="mt-10">
          Ana sayfaya dön
        </ButtonLink>
      </div>
    </section>
  )
}
