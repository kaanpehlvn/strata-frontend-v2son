import type { Metadata } from 'next'
import Link from 'next/link'
import { Reveal } from '@/components/site/reveal'
import { ButtonLink, PageHero, SectionLabel } from '@/components/site/primitives'
import { siteConfig } from '@/lib/data/site'

export const metadata: Metadata = {
  title: 'Hakkımızda',
  description:
    'STRATA, Dokuz Eylül Üniversitesi öğrencilerinin bilim, teknoloji, tasarım, araştırma ve üretim alanlarında birlikte çalıştığı bir öğrenci topluluğudur.',
  alternates: { canonical: '/hakkimizda' },
}

const values = [
  ['Yaparak öğrenme', 'Her üyemiz bir projede somut sorumluluk alır.'],
  ['Açık belgeleme', 'Teknik hafızayı kaydeder, sonraki ekibe devrederiz.'],
  ['Birlikte tasarım', 'Mekanik, elektronik, yazılım ve yapay zekâ aynı masada buluşur.'],
  ['Güvenli üretim', 'Atölyede güvenlik kurallarından taviz vermeyiz.'],
] as const

const projects = [
  {
    title: 'Çelik Kubbe Hava Savunma Sistemi',
  },
  {
    title: 'Maglev Treni',
  },
] as const

export default function AboutPage() {
  return (
    <>
      <PageHero
        label="Hakkımızda"
        title={
          <>
            Merakla
            <br />
            <span className="text-signal">üreten</span> bir topluluk.
          </>
        }
        intro={`${siteConfig.fullName}, ${siteConfig.university} öğrencilerinin farklı ilgi alanlarını bir araya getirerek araştırdığı, tasarladığı ve ürettiği bir öğrenci topluluğudur.`}
      />

      <section id="biz-kimiz" className="py-16 md:py-24">
        <div className="container-x">
          <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
            <Reveal className="lg:col-span-5">
              <SectionLabel index="01">Biz kimiz?</SectionLabel>
              <h2 className="display mt-7 text-[clamp(2.5rem,5vw,4.75rem)]">Bilgiyi atölyede sınarız.</h2>
            </Reveal>
            <Reveal className="space-y-5 text-pretty text-lg leading-relaxed text-paper/70 lg:col-span-6 lg:col-start-7" delay={0.1}>
              <p>STRATA, derste öğrenilen bilgiyi gerçek sistemler üzerinde denemek için kurulmuş bir öğrenci topluluğudur.</p>
              <p>Bir problemi tanımlar, prototipi kurar, test eder ve teknik hafızayı paylaşırız.</p>
            </Reveal>
          </div>

          <ul className="mt-14 grid gap-px bg-paper/15 sm:grid-cols-2 lg:grid-cols-4">
            {values.map(([title, body], index) => (
              <li key={title} className="bg-ink p-6 md:p-7">
                <span className="label text-signal">{String(index + 1).padStart(2, '0')}</span>
                <h3 className="display mt-10 text-2xl">{title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-paper/65">{body}</p>
              </li>
            ))}
          </ul>

        </div>
      </section>

      <section id="projeler" className="border-t border-paper/10 py-16 md:py-24">
        <div className="container-x">
          <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
            <Reveal className="lg:col-span-4">
              <SectionLabel index="02">Projeler</SectionLabel>
              <h2 className="display mt-7 text-[clamp(2.5rem,5vw,4.75rem)]">Soruları sisteme dönüştürürüz.</h2>
            </Reveal>
            <Reveal className="lg:col-span-7 lg:col-start-6" delay={0.1}>
              <ul className="divide-y divide-paper/15 border-y border-paper/15">
                {projects.map(({ title }) => (
                  <li key={title} className="py-8 text-center sm:py-10">
                    <div>
                      <h3 className="display text-2xl md:text-3xl">{title}</h3>
                    </div>
                  </li>
                ))}
              </ul>
              <Link href="/projeler" className="strata-subtle-link mt-6 flex justify-center">
                Projeleri gör
              </Link>
            </Reveal>
          </div>
        </div>
      </section>

      <section id="katil" className="border-t border-paper/10 py-20 md:py-28">
        <div className="container-x flex flex-col items-start justify-between gap-8 md:flex-row md:items-center">
          <div>
            <SectionLabel index="03">Katılın</SectionLabel>
            <h2 className="display mt-6 max-w-2xl text-[clamp(2.25rem,5vw,4.5rem)]">Bizimle çalışmak ister misiniz?</h2>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row">
            <ButtonLink href="/uye-on-kayit">Ön kayıt</ButtonLink>
          </div>
        </div>
      </section>
    </>
  )
}
