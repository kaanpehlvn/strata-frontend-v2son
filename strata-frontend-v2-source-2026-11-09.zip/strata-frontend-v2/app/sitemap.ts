import type { MetadataRoute } from 'next'
import { projects } from '@/lib/data/projects'

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://deustrata.com.tr'

export default function sitemap(): MetadataRoute.Sitemap {
  const staticRoutes = [
    '/',
    '/hakkimizda',
    '/projeler',
    '/iletisim',
    '/uye-on-kayit',
    '/basvuru-durumu',
  ]

  return [
    ...staticRoutes.map((route) => ({ url: `${siteUrl}${route}`, changeFrequency: 'weekly' as const, priority: route === '/' ? 1 : 0.7 })),
    ...projects.map((project) => ({ url: `${siteUrl}/projeler/${project.slug}`, changeFrequency: 'monthly' as const, priority: 0.6 })),
  ]
}
