import type { Metadata } from 'next'
import { ArrowUpRight, MapPin, Navigation } from 'lucide-react'
import { ContactForm } from '@/components/forms/contact-form'
import { SectionLabel } from '@/components/site/primitives'
import { SocialLinks } from '@/components/site/social-links'
import { siteConfig } from '@/lib/data/site'

export const metadata: Metadata = {
  title: '\u0130leti\u015fim',
  description: 'STRATA ile ileti\u015fime ge\u00e7in: genel sorular, destek ve i\u015f birli\u011fi talepleri.',
  alternates: { canonical: '/iletisim' },
}

const mapQuery = encodeURIComponent(siteConfig.address)
const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${mapQuery}`
const directionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${mapQuery}`
const embedUrl = `https://www.google.com/maps?q=${mapQuery}&output=embed`

function MapCard() {
  return (
    <div className="overflow-hidden border border-ink/15 bg-graphite">
      <a
        href={mapsUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label={'Google Maps\'te STRATA adresini a\u00e7'}
        className="group relative block"
      >
        <iframe
          title={'STRATA adres haritas\u0131'}
          src={embedUrl}
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          aria-hidden="true"
          tabIndex={-1}
          className="pointer-events-none h-72 w-full grayscale contrast-125 opacity-80 transition-[filter,opacity] duration-500 group-hover:grayscale-0 group-hover:opacity-100 sm:h-80"
        />
        <span className="absolute bottom-4 right-4 inline-flex items-center gap-2 bg-ink px-4 py-3 text-xs font-semibold uppercase tracking-[0.12em] text-paper transition-transform duration-300 group-hover:-translate-y-1">
          {'Haritada a\u00e7'} <ArrowUpRight aria-hidden="true" className="size-4" />
        </span>
      </a>
      <div className="border-t border-paper/15 p-5 text-paper sm:p-6">
        <div className="flex items-start gap-3">
          <MapPin aria-hidden="true" className="mt-0.5 size-5 shrink-0 text-signal" />
          <div>
            <p className="label text-paper/50">Adres</p>
            <p className="mt-2 max-w-sm text-sm leading-relaxed text-paper/85">{siteConfig.address}</p>
            <p className="label mt-3 text-paper/45">{siteConfig.coordinates}</p>
          </div>
        </div>
        <a
          href={directionsUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-paper transition-colors hover:text-signal focus-visible:outline-2 focus-visible:outline-offset-4"
        >
          <Navigation aria-hidden="true" className="size-4" />
          {'Yol tarifi al'}
        </a>
      </div>
    </div>
  )
}

export default function ContactPage() {
  return (
    <>
      <section className="relative border-b border-paper/10 pb-12 pt-32 md:pb-16 md:pt-40">
        <div className="container-x grid gap-10 lg:grid-cols-12 lg:items-center lg:gap-14">
          <div className="lg:col-span-7">
            <SectionLabel className="text-paper/70">{'\u0130leti\u015fim'}</SectionLabel>
            <h1 className="display mt-6 text-[clamp(3rem,8vw,7.5rem)]">
              Bize <span className="text-signal">{'yaz\u0131n.'}</span>
            </h1>
            <p className="mt-6 max-w-xl text-pretty text-base leading-relaxed text-paper/70 md:text-lg">
              {'Topluluk, destek veya i\u015f birli\u011fi hakk\u0131nda bize ula\u015f\u0131n.'}
            </p>
          </div>

          <div className="border-t border-paper/15 pt-5 lg:col-span-4 lg:col-start-9 lg:border-l lg:border-t-0 lg:pl-9 lg:pt-0">
            <p className="label text-paper/50">E-posta</p>
            <a
              href={`mailto:${siteConfig.email}`}
              className="mt-2 inline-block break-all text-base font-semibold tracking-tight text-paper/90 underline-offset-4 transition-colors hover:text-signal hover:underline sm:text-lg"
            >
              {siteConfig.email}
            </a>
            <div className="mt-6">
              <p className="label text-paper/50">Sosyal medya</p>
              <div className="mt-3">
                <SocialLinks dark />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-paper py-14 text-ink md:py-24">
        <div className="container-x grid gap-10 lg:grid-cols-12 lg:gap-14">
          <div className="border border-ink/15 bg-paper p-6 md:p-9 lg:col-span-7">
            <div className="flex items-end justify-between gap-6 border-b border-ink/15 pb-6">
              <div>
                <SectionLabel index="01" className="text-ink/60">{'Mesaj g\u00f6nderin'}</SectionLabel>
                <h2 className="display mt-4 text-[clamp(2.25rem,4vw,4rem)]">Bir soru, bir fikir.</h2>
              </div>
              <span aria-hidden="true" className="hidden size-10 border border-ink/25 sm:block" />
            </div>
            <div className="pt-8">
              <ContactForm />
            </div>
          </div>

          <aside className="lg:col-span-5">
            <MapCard />
          </aside>
        </div>
      </section>
    </>
  )
}
