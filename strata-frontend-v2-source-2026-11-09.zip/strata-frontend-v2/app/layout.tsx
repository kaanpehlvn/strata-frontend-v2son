import type { Metadata, Viewport } from 'next'
import { SiteHeader } from '@/components/site/site-header'
import { SiteFooter } from '@/components/site/site-footer'
import { siteConfig, socialLinks } from '@/lib/data/site'
import './globals.css'

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://deustrata.com.tr'

const organizationJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: siteConfig.fullName,
  alternateName: siteConfig.name,
  url: siteUrl,
  logo: `${siteUrl}/images/strata-transparent-logo.png`,
  description:
    'Dokuz Eylül Üniversitesi öğrencilerinin bilim, teknoloji, tasarım, araştırma ve üretim alanlarında birlikte çalıştığı öğrenci topluluğu.',
  email: siteConfig.email,
  address: {
    '@type': 'PostalAddress',
    streetAddress: siteConfig.address,
    addressLocality: 'İzmir',
    addressCountry: 'TR',
  },
  sameAs: socialLinks.map((link) => link.href).filter(Boolean),
}

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: 'STRATA — Dokuz Eylül Üniversitesi Araştırma ve Üretim Topluluğu',
    template: '%s — STRATA',
  },
  description:
    'STRATA, Dokuz Eylül Üniversitesi öğrencilerinin bilim, teknoloji, tasarım, araştırma ve üretim alanlarında birlikte çalıştığı bir öğrenci topluluğudur.',
  icons: {
    icon: '/favicon.svg',
  },
  openGraph: {
    type: 'website',
    locale: 'tr_TR',
    siteName: 'STRATA',
    title: 'STRATA — Araştırma ve Üretim Topluluğu',
    description: 'Bilim, teknoloji, tasarım, araştırma ve üretim alanlarında birlikte çalışan öğrenci topluluğu.',
    images: [{ url: '/strata-wordmark.jpg', width: 1200, height: 630, alt: 'STRATA çalışma alanı' }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'STRATA — Araştırma ve Üretim Topluluğu',
    description: 'Bilim, teknoloji, tasarım, araştırma ve üretim alanlarında birlikte çalışan öğrenci topluluğu.',
    images: ['/strata-wordmark.jpg'],
  },
  robots: { index: true, follow: true },
}

export const viewport: Viewport = {
  themeColor: '#101113',
  colorScheme: 'dark',
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="tr" data-scroll-behavior="smooth">
      <body className="min-h-screen bg-ink text-paper antialiased">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationJsonLd) }}
        />
        <a
          href="#icerik"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:bg-signal focus:px-4 focus:py-2 focus:text-paper"
        >
          İçeriğe geç
        </a>
        <SiteHeader />
        <main id="icerik">{children}</main>
        <SiteFooter />
      </body>
    </html>
  )
}
