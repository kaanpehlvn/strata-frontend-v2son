import type { Metadata } from 'next'
import { JoinForm } from '@/components/forms/join-form'
import { PageHero } from '@/components/site/primitives'

export const metadata: Metadata = {
  title: 'Üye Ön Kayıt',
  description: 'STRATA topluluğuna üye olmak için ön kayıt formunu doldurun.',
  alternates: { canonical: '/uye-on-kayit' },
}

const steps = [
  { title: 'Formu doldurun', body: 'Bölümünüzü, ilgi alanınızı ve tercih ettiğiniz ekibi belirtin.' },
  { title: 'Ön inceleme', body: 'Ekip sorumluları başvurunuzu inceler; bu sırada sizden işlem beklenmez.' },
  { title: 'Kısa görüşme', body: 'Uygun bulunan adaylarla yaklaşık 20 dakikalık, sınavsız bir tanışma görüşmesi yapılır.' },
  { title: 'Uyum oturumu', body: 'Kabul edilen üyeler atölye güvenliği ve ekip çalışma düzeni için bir oturuma katılır.' },
]

export default function JoinPage() {
  return (
    <>
      <PageHero
        label="Üye Ön Kayıt"
        title={
          <>
            Aramıza
            <br />
            <span className="text-signal">katıl.</span>
          </>
        }
        intro="Robotik deneyimi gerekmez. Merak, düzenli çalışma isteği ve bir ekiple üretme heveşi yeterlidir."
      />

      <section className="bg-paper py-16 text-ink md:py-24">
        <div className="container-x grid gap-16 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <JoinForm />
          </div>

          <aside className="lg:col-span-4 lg:col-start-9" aria-label="Başvuru süreci">
            <p className="label text-ink/50">Süreç nasıl işler?</p>
            <ol className="mt-6 border-t border-ink/20">
              {steps.map((s, i) => (
                <li key={s.title} className="grid grid-cols-[2.5rem_1fr] gap-3 border-b border-ink/20 py-5">
                  <span className="label pt-1 text-signal">{String(i + 1).padStart(2, '0')}</span>
                  <div>
                    <h3 className="font-semibold">{s.title}</h3>
                    <p className="mt-1 text-pretty text-sm leading-relaxed text-ink/65">{s.body}</p>
                  </div>
                </li>
              ))}
            </ol>
          </aside>
        </div>
      </section>
    </>
  )
}
