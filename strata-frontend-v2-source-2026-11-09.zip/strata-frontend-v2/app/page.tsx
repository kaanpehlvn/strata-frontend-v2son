import type { Metadata } from 'next'
import { ExperimentalClose } from '@/components/home/experimental-close'
import { ExperimentalHero } from '@/components/home/experimental-hero'

export const metadata: Metadata = {
  alternates: { canonical: '/' },
}

export default function HomePage() {
  return (
    <>
      <ExperimentalHero />
      <ExperimentalClose />
    </>
  )
}
