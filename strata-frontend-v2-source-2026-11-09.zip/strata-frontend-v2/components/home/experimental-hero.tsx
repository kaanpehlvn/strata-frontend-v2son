import Image from 'next/image'
import Link from 'next/link'
import { ArrowUpRight } from 'lucide-react'
import { EngineeringTrace } from '@/components/home/engineering-trace'

export function ExperimentalHero() {
  return (
    <>
      <section className="relative isolate min-h-[100svh] overflow-hidden bg-brand-black text-paper">
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 opacity-30 [background-image:linear-gradient(to_right,rgba(245,245,242,.08)_1px,transparent_1px),linear-gradient(to_bottom,rgba(245,245,242,.08)_1px,transparent_1px)] [background-size:clamp(2.5rem,6vw,6rem)_clamp(2.5rem,6vw,6rem)]" />
        <div className="absolute inset-y-0 right-0 hidden w-[42%] border-l border-paper/5 lg:block">
          <Image
            src="/images/hero.jpg"
            alt="Bir laboratuvar hücresinde devre kartına temas eden Universal Robots UR3 robotik kol"
            fill
            priority
            sizes="42vw"
            className="object-cover grayscale opacity-30 mix-blend-screen"
          />
          <div aria-hidden="true" className="pointer-events-none absolute inset-y-0 left-0 w-28 bg-gradient-to-r from-brand-black via-brand-black/70 to-transparent" />
          <div aria-hidden="true" className="pointer-events-none absolute inset-0 bg-brand-black/75" />
          <a
            href="https://commons.wikimedia.org/wiki/File:Bra%C3%A7o_rob%C3%B3tico_colaborativo_Universal_Robots_UR3_no_Laborat%C3%B3rio_de_Investiga%C3%A7%C3%A3o_e_Inova%C3%A7%C3%A3o,_CeDRI,_Bragan%C3%A7a.jpg"
            target="_blank"
            rel="noreferrer"
            className="absolute bottom-3 right-3 z-10 text-[10px] text-paper/55 underline-offset-2 hover:text-paper hover:underline"
          >
            Foto: Caio.st.oliveira / Wikimedia Commons · CC BY-SA 4.0
          </a>
        </div>

        <div className="container-x relative flex min-h-[100svh] flex-col pb-7 pt-[7rem] md:py-10 md:pt-28">
          <div className="flex flex-1 items-center">
            <div className="mx-auto grid w-full max-w-[88rem] gap-10 pb-10 lg:grid-cols-12 lg:pb-16">
            <div className="lg:col-span-8">
              <h1 className="display max-w-5xl text-[clamp(2.75rem,13vw,5rem)] uppercase leading-[0.86] tracking-[-0.075em] lg:text-[clamp(3.25rem,9.5vw,9.5rem)]">
                Sistemleri
                <br />
                <span className="text-steel">katman katman</span>
                <br />
                kuruyoruz.
              </h1>
            </div>

            <div className="flex flex-col justify-end gap-8 lg:col-span-4 lg:pb-2">
              <p className="editorial max-w-[26ch] break-words text-[clamp(1.35rem,4.5vw,1.875rem)] text-paper/80">
                Bilim, teknoloji, tasarım ve üretimi aynı çalışma kültüründe buluşturan öğrenci topluluğu.
              </p>
              <div className="flex flex-wrap items-center gap-x-7 gap-y-4">
                <Link href="/uye-on-kayit" className="strata-primary-link">
                  Üye ön kayıt <ArrowUpRight aria-hidden="true" className="size-4" />
                </Link>
              </div>
            </div>
            </div>
          </div>

          <div className="hidden items-center justify-between border-t border-paper/15 pt-4 text-text-muted-dark md:flex">
            <span className="technical">01 / BAŞLANGIÇ</span>
            <span className="technical">BİR FİKİR, BİRDEN FAZLA KATMAN</span>
          </div>
        </div>
      </section>
      <EngineeringTrace />
    </>
  )
}
