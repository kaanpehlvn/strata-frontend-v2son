'use client'

import Link from 'next/link'
import { ArrowUpRight } from 'lucide-react'
import { useState } from 'react'
import { publicProjectContext } from '@/lib/data/public-project'
import { cn } from '@/lib/utils'

type ModuleKey = 'robotik' | 'yazilim' | 'elektronik'
type PartId = 'base' | 'joint' | 'tool' | 'input' | 'logic' | 'output' | 'power' | 'core' | 'signal'

type Part = {
  id: PartId
  label: string
  detail: string
  role: string
}

const modules: Record<ModuleKey, { label: string; code: string; summary: string; technologies: string[]; parts: Part[] }> = {
  robotik: {
    label: 'Robotik',
    code: 'MOD / RBT',
    summary: 'Mekanizma, hareket ve kontrol düşüncesiyle fiziksel sistemlerin nasıl kurulacağını araştırırız.',
    technologies: ['Mekanik', 'Hareket', 'Kontrol'],
    parts: [
      { id: 'base', label: 'Taban', detail: 'Sistemin zemine bağlanan ve hareketi taşıyan katmanı.', role: 'MEKANİK / 01' },
      { id: 'joint', label: 'Eklem', detail: 'Hareket kararının fiziksel kuvvete dönüştüğü ara parça.', role: 'MEKANİK / 02' },
      { id: 'tool', label: 'Uç efektör', detail: 'Sistemin çevreyle temas eden son çalışma noktası.', role: 'MEKANİK / 03' },
    ],
  },
  yazilim: {
    label: 'Yazılım',
    code: 'MOD / SW',
    summary: 'Algılama, karar verme ve sistem davranışını yazılım katmanında modelleyip doğrularız.',
    technologies: ['Algılama', 'Karar', 'Modelleme'],
    parts: [
      { id: 'input', label: 'Girdi', detail: 'Dış dünyadan gelen ölçüm ve sinyallerin ilk karşılandığı katman.', role: 'VERİ / 01' },
      { id: 'logic', label: 'Mantık', detail: 'Verinin yorumlanıp bir sonraki davranışa dönüştürüldüğü katman.', role: 'VERİ / 02' },
      { id: 'output', label: 'Çıktı', detail: 'Kararın sisteme geri gönderildiği ve gözlemlenebilir hâle geldiği katman.', role: 'VERİ / 03' },
    ],
  },
  elektronik: {
    label: 'Elektronik',
    code: 'MOD / ELX',
    summary: 'Sinyal, güç ve iletişim katmanlarını ölçülebilir donanım kararlarına dönüştürürüz.',
    technologies: ['Sinyal', 'Güç', 'İletişim'],
    parts: [
      { id: 'power', label: 'Güç', detail: 'Sistemin enerji girişini güvenli ve izlenebilir hâle getiren katman.', role: 'DONANIM / 01' },
      { id: 'core', label: 'Çekirdek', detail: 'Elektronik kararların ve ölçümlerin toplandığı merkez parça.', role: 'DONANIM / 02' },
      { id: 'signal', label: 'Sinyal', detail: 'Parçalar arasındaki iletişim ve kontrol akışının çıkış noktası.', role: 'DONANIM / 03' },
    ],
  },
}

function PartButton({ part, active, className, onSelect }: Readonly<{ part: Part; active: boolean; className: string; onSelect: (part: PartId) => void }>) {
  return (
    <button
      type="button"
      aria-pressed={active}
      aria-label={`${part.label}: ${part.detail}`}
      onClick={() => onSelect(part.id)}
      className={cn(
        'group absolute z-20 min-w-0 touch-manipulation select-none border text-left transition-[background-color,border-color,box-shadow,transform] duration-200 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-ink',
        active
          ? 'border-ink bg-ink text-paper shadow-[8px_8px_0_rgba(16,17,19,.18)]'
          : 'border-ink/50 bg-paper text-ink hover:-translate-y-1 hover:border-ink hover:bg-white',
        className,
      )}
    >
      <span className="technical block truncate px-2 pt-2 text-[0.52rem] opacity-60 sm:px-4 sm:pt-3 sm:text-[0.6rem]">{part.role}</span>
      <span className="block break-words px-2 pb-3 pt-1 text-[clamp(0.85rem,3.8vw,1.5rem)] font-semibold uppercase leading-[0.95] tracking-[-0.04em] sm:px-4 sm:pb-4 sm:pt-2">{part.label}</span>
      <span aria-hidden="true" className="absolute -right-1.5 -top-1.5 size-3 border border-current bg-inherit" />
    </button>
  )
}

function RobotikAssembly({ activePart, onSelect }: Readonly<{ activePart: PartId; onSelect: (part: PartId) => void }>) {
  const parts = modules.robotik.parts
  return (
    <div className="relative min-h-[23rem] overflow-hidden bg-paper text-ink sm:min-h-[31rem]">
      <div aria-hidden="true" className="absolute inset-x-8 top-1/2 h-px bg-ink/15 sm:inset-x-12" />
      <div aria-hidden="true" className="absolute bottom-12 left-[17%] h-24 w-1/2 border-b-2 border-l-2 border-ink sm:bottom-16 sm:left-[21%]" />
      <div aria-hidden="true" className="absolute bottom-[7.4rem] left-[47%] h-[9.5rem] w-px rotate-[18deg] bg-ink/70 sm:bottom-[9.5rem] sm:h-44" />
      <PartButton part={parts[0]} active={activePart === 'base'} onSelect={onSelect} className="bottom-10 left-[8%] w-[38%] sm:bottom-14 sm:left-[13%] sm:w-48" />
      <PartButton part={parts[1]} active={activePart === 'joint'} onSelect={onSelect} className="bottom-[41%] left-[38%] w-[34%] rotate-[-8deg] sm:bottom-[42%] sm:left-[39%] sm:w-52" />
      <PartButton part={parts[2]} active={activePart === 'tool'} onSelect={onSelect} className="right-[8%] top-[16%] w-[36%] rotate-[7deg] sm:right-[13%] sm:top-[15%] sm:w-48" />
      <div className="technical absolute bottom-5 left-5 text-steel-dark sm:bottom-8 sm:left-8">KURULUM / MEKANİK AKIŞ</div>
    </div>
  )
}

function YazilimAssembly({ activePart, onSelect }: Readonly<{ activePart: PartId; onSelect: (part: PartId) => void }>) {
  const parts = modules.yazilim.parts
  return (
    <div className="relative min-h-[23rem] overflow-hidden bg-paper text-ink sm:min-h-[31rem]">
      <div aria-hidden="true" className="absolute left-[22%] right-[22%] top-1/2 h-px bg-ink/50" />
      <div aria-hidden="true" className="absolute left-1/2 top-[28%] h-[44%] w-px bg-ink/20" />
      <div aria-hidden="true" className="absolute left-[22%] top-1/2 size-3 -translate-x-1/2 -translate-y-1/2 bg-ink" />
      <div aria-hidden="true" className="absolute left-1/2 top-1/2 size-3 -translate-x-1/2 -translate-y-1/2 bg-ink" />
      <div aria-hidden="true" className="absolute left-[78%] top-1/2 size-3 -translate-x-1/2 -translate-y-1/2 bg-ink" />
      <PartButton part={parts[0]} active={activePart === 'input'} onSelect={onSelect} className="left-[5%] top-[35%] w-[30%] sm:left-[8%] sm:w-48" />
      <PartButton part={parts[1]} active={activePart === 'logic'} onSelect={onSelect} className="left-1/2 top-[57%] w-[32%] -translate-x-1/2 sm:w-56" />
      <PartButton part={parts[2]} active={activePart === 'output'} onSelect={onSelect} className="right-[5%] top-[35%] w-[30%] sm:right-[8%] sm:w-48" />
      <div className="technical absolute bottom-5 left-5 text-steel-dark sm:bottom-8 sm:left-8">KURULUM / VERİ AKIŞI</div>
    </div>
  )
}

function ElektronikAssembly({ activePart, onSelect }: Readonly<{ activePart: PartId; onSelect: (part: PartId) => void }>) {
  const parts = modules.elektronik.parts
  return (
    <div className="relative min-h-[23rem] overflow-hidden bg-paper text-ink sm:min-h-[31rem]">
      <div aria-hidden="true" className="absolute left-[9%] right-[9%] top-[18%] bottom-[18%] border-2 border-ink sm:left-[13%] sm:right-[13%]" />
      <div aria-hidden="true" className="absolute left-[13%] right-[13%] top-1/2 h-px bg-ink/50 sm:left-[17%] sm:right-[17%]" />
      <div aria-hidden="true" className="absolute left-1/2 top-[18%] bottom-[18%] w-px bg-ink/30" />
      <PartButton part={parts[0]} active={activePart === 'power'} onSelect={onSelect} className="left-[5%] top-[31%] w-[29%] sm:left-[10%] sm:w-48" />
      <PartButton part={parts[1]} active={activePart === 'core'} onSelect={onSelect} className="left-1/2 top-[39%] w-[34%] -translate-x-1/2 sm:w-56" />
      <PartButton part={parts[2]} active={activePart === 'signal'} onSelect={onSelect} className="right-[5%] top-[58%] w-[29%] sm:right-[10%] sm:w-48" />
      <div className="technical absolute bottom-5 left-5 text-steel-dark sm:bottom-8 sm:left-8">KURULUM / KART İLİŞKİSİ</div>
    </div>
  )
}

function AssemblyCanvas({ active, activePart, onSelect }: Readonly<{ active: ModuleKey; activePart: PartId; onSelect: (part: PartId) => void }>) {
  if (active === 'robotik') return <RobotikAssembly activePart={activePart} onSelect={onSelect} />
  if (active === 'yazilim') return <YazilimAssembly activePart={activePart} onSelect={onSelect} />
  return <ElektronikAssembly activePart={activePart} onSelect={onSelect} />
}

export function EngineeringTrace() {
  const [active, setActive] = useState<ModuleKey>('robotik')
  const [activePart, setActivePart] = useState<PartId>('base')
  const module = modules[active]
  const selectedPart = module.parts.find((part) => part.id === activePart) ?? module.parts[0]

  const selectModule = (key: ModuleKey) => {
    setActive(key)
    setActivePart(modules[key].parts[0].id)
  }

  return (
    <section className="bg-ink py-20 text-paper md:py-28">
      <div className="container-x">
        <div className="grid gap-14 lg:grid-cols-12 lg:gap-20">
          <div className="lg:col-span-4">
            <p className="technical flex items-center gap-3 text-text-muted-dark">
              <span aria-hidden="true" className="inline-block size-2 bg-paper" />
              <span>02 / STRATA ÜRETİM LABORATUVARI</span>
            </p>
            <h2 className="mt-8 text-[clamp(3rem,6vw,6rem)] font-semibold uppercase leading-[0.88] tracking-[-0.07em]">
              Sistemin
              <br />
              <span className="text-steel">hangi katmanı?</span>
            </h2>
            <p className="mt-10 max-w-sm break-words text-base leading-[1.65] text-text-muted-dark sm:text-lg">
              Bir modül seçin, sonra kompozisyondaki parçaları keşfedin. Her parça farklı bir üretim rolünü açar.
            </p>
            <p className="technical mt-8 text-paper">MODÜLÜ SEÇ / PARÇALARI KEŞFET</p>

            <fieldset className="mt-5 flex flex-wrap gap-2">
              <legend className="sr-only">Üretim alanı seçimi</legend>
              {(Object.keys(modules) as ModuleKey[]).map((key) => (
                <button
                  key={key}
                  type="button"
                  aria-pressed={active === key}
                  onClick={() => selectModule(key)}
                  className={`technical border px-4 py-3 text-left transition-colors duration-200 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-paper ${
                    active === key ? 'border-paper bg-paper text-ink' : 'border-paper/25 text-text-muted-dark hover:border-paper hover:text-paper'
                  }`}
                >
                  {modules[key].label}
                </button>
              ))}
            </fieldset>
          </div>

          <div className="lg:col-span-8">
            <div className="grid gap-8 border-y border-paper/15 py-6 sm:grid-cols-[1fr_15rem] sm:items-end">
              <div>
                <p className="technical text-text-muted-dark">{modules[active].code}</p>
                <h3 className="mt-4 text-[clamp(2.25rem,5vw,5rem)] font-semibold uppercase leading-[0.88] tracking-[-0.07em]">{module.label}</h3>
              </div>
              <p className="break-words text-sm leading-relaxed text-text-muted-dark sm:text-right">{module.summary}</p>
            </div>

            <div className="relative mt-8 overflow-hidden border border-paper/20" aria-label={`${module.label} interaktif mühendislik kompozisyonu`}>
              <div key={active} className="animate-assembly-state">
                <AssemblyCanvas active={active} activePart={activePart} onSelect={setActivePart} />
              </div>
            </div>

            <div className="mt-8 grid gap-6 border-t border-paper/15 pt-6 sm:grid-cols-[1fr_auto] sm:items-end" aria-live="polite">
              <div>
                <p className="technical text-text-muted-dark">{selectedPart.role}</p>
                <p className="editorial mt-2 text-3xl">{selectedPart.label}</p>
                <p className="mt-3 max-w-xl text-base leading-relaxed text-text-muted-dark">{selectedPart.detail}</p>
                <div className="mt-4 flex flex-wrap gap-x-4 gap-y-2 technical text-text-muted-dark">
                  {module.technologies.map((technology) => <span key={technology}>{technology}</span>)}
                </div>
              </div>
              <Link href="/projeler" className="strata-subtle-link shrink-0">
                {publicProjectContext.category} <ArrowUpRight aria-hidden="true" className="size-4" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
