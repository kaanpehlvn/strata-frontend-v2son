import Link from 'next/link'
import { ArrowUpRight } from 'lucide-react'

export function ExperimentalClose() {
  return (
    <section className="relative overflow-hidden border-t border-paper/15 bg-graphite py-20 text-paper md:py-28">
      <div aria-hidden="true" className="absolute inset-x-0 top-1/2 h-px bg-paper/10" />
      <div className="container-x relative">
        <p className="technical text-text-muted-dark">05 / SIRADAKİ KATMAN</p>
        <div className="mt-8 grid gap-8 lg:grid-cols-12 lg:items-end">
          <h2 className="display max-w-5xl text-[clamp(3rem,9vw,9rem)] uppercase leading-[0.84] tracking-[-0.085em] lg:col-span-8">
            Soruyu
            <br />
            <span className="text-steel">birlikte</span>
            <br />
            kurun.
          </h2>
          <div className="lg:col-span-4">
            <p className="editorial max-w-[28ch] break-words text-[clamp(1.35rem,4.5vw,1.875rem)] text-text-muted-dark">
              STRATA’nın bir sonraki çalışma alanı, merak eden ve üretmek isteyen öğrencilerle başlar.
            </p>
            <Link href="/uye-on-kayit" className="strata-primary-link mt-8">
              Üye ön kayıt <ArrowUpRight aria-hidden="true" className="size-4" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
