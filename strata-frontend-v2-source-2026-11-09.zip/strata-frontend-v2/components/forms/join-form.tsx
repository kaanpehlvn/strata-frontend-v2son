'use client'

import Link from 'next/link'
import { useState, type FormEvent } from 'react'
import { Check } from 'lucide-react'
import { emailPattern, Field, SelectInput, TextArea, TextInput } from '@/components/forms/fields'
import { demoApplications } from '@/lib/data/applications'
import { teamGroups } from '@/lib/data/team'

const motivationHint =
  'Önceki deneyim şart değil; ne öğrenmek ve ne üretmek istediğinizi yazmanız yeterli.'

const years = ['Hazırlık', '1. sınıf', '2. sınıf', '3. sınıf', '4. sınıf', 'Lisansüstü']

type Key = 'name' | 'email' | 'department' | 'studentNumber' | 'year' | 'team' | 'motivation' | 'consent'
type Errors = Partial<Record<Key, string>>

export function JoinForm() {
  const [errors, setErrors] = useState<Errors>({})
  const [done, setDone] = useState(false)

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const data = new FormData(e.currentTarget)
    const next: Errors = {}
    const get = (k: string) => String(data.get(k) ?? '').trim()

    if (get('name').length < 2) next.name = 'Lütfen adınızı ve soyadınızı yazın.'
    if (!emailPattern.test(get('email'))) next.email = 'Geçerli bir e-posta adresi girin.'
    if (get('department').length < 2) next.department = 'Bölümünüzü yazın.'
    if (!/^\d{4,16}$/.test(get('studentNumber'))) {
      next.studentNumber = 'Geçerli bir öğrenci numarası girin.'
    }
    if (!get('year')) next.year = 'Sınıfınızı seçin.'
    if (!get('team')) next.team = 'Bir ekip seçin.'
    if (get('motivation').length < 30) next.motivation = 'Lütfen en az 30 karakterle kendinizi tanıtın.'
    if (data.get('consent') !== 'on') next.consent = 'Devam etmek için onay vermeniz gerekir.'

    setErrors(next)
    if (Object.keys(next).length === 0) setDone(true)
  }

  if (done) {
    return (
      <div role="status" className="border border-ink/20 p-8 md:p-12">
        <span className="flex size-12 items-center justify-center bg-signal text-paper">
          <Check aria-hidden="true" className="size-6" />
        </span>
        <h3 className="display mt-8 text-3xl md:text-4xl">Ön kayıt formu tamamlandı.</h3>
        <p className="mt-4 max-w-lg text-pretty leading-relaxed text-ink/70">
          Bu bir örnek sitedir; başvurunuz kaydedilmedi. Gerçek sistemde başvurunuza bir referans numarası
          atanır ve süreci Başvuru Durumu sayfasından izlersiniz. Deneme için örnek bir numarayı
          kullanabilirsiniz:
        </p>
        <p className="label mt-5 inline-block border border-ink/25 px-3 py-2 text-ink">
          {demoApplications[0].reference}
        </p>
        <div className="mt-8 flex flex-wrap gap-6">
          <Link href="/basvuru-durumu" className="label border-b border-current pb-1 hover:text-signal">
            Başvuru durumuna git
          </Link>
          <button
            type="button"
            onClick={() => setDone(false)}
            className="label border-b border-current pb-1 hover:text-signal"
          >
            Formu yeniden doldur
          </button>
        </div>
      </div>
    )
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2">
        <Field id="name" label="Ad Soyad" required error={errors.name}>
          <TextInput id="name" autoComplete="name" error={errors.name} />
        </Field>
        <Field id="email" label="Öğrenci e-postası" required error={errors.email}>
          <TextInput id="email" type="email" autoComplete="email" error={errors.email} />
        </Field>
        <Field id="department" label="Bölüm" required error={errors.department}>
          <TextInput id="department" error={errors.department} />
        </Field>
        <Field id="studentNumber" label="Öğrenci numarası" required error={errors.studentNumber}>
          <TextInput
            id="studentNumber"
            inputMode="numeric"
            autoComplete="off"
            placeholder="Örn. 2020123456"
            error={errors.studentNumber}
          />
        </Field>
        <Field id="year" label="Sınıf" required error={errors.year}>
          <SelectInput id="year" defaultValue="" error={errors.year}>
            <option value="" disabled>
              Seçin
            </option>
            {years.map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </SelectInput>
        </Field>
      </div>

      <Field id="team" label="Tercih ettiğiniz ekip" required error={errors.team}>
        <SelectInput id="team" defaultValue="" error={errors.team}>
          <option value="" disabled>
            Seçin
          </option>
          {teamGroups.map((g) => (
            <option key={g.slug} value={g.slug}>
              {g.name}
            </option>
          ))}
        </SelectInput>
      </Field>

      <Field
        id="motivation"
        label="Kendinizi ve motivasyonunuzu anlatın"
        required
        hint={motivationHint}
        error={errors.motivation}
      >
        <TextArea id="motivation" error={errors.motivation} hint={motivationHint} />
      </Field>

      <div>
        <label className="flex cursor-pointer items-start gap-3">
          <input
            type="checkbox"
            name="consent"
            aria-invalid={errors.consent ? true : undefined}
            aria-describedby={errors.consent ? 'consent-error' : undefined}
            className="mt-1 size-5 shrink-0 accent-signal"
          />
          <span className="text-sm leading-relaxed text-ink/75">
            Başvuru değerlendirmesi amacıyla bilgilerimin topluluk yönetimi tarafından işlenmesini kabul
            ediyorum.
          </span>
        </label>
        {errors.consent ? (
          <p id="consent-error" role="alert" className="mt-2 text-sm font-medium text-signal">
            {errors.consent}
          </p>
        ) : null}
      </div>

      <button
        type="submit"
        className="inline-flex h-12 items-center bg-ink px-8 text-sm font-semibold uppercase tracking-[0.14em] text-paper transition-colors duration-300 hover:bg-signal"
      >
        Ön kaydı gönder
      </button>
    </form>
  )
}
