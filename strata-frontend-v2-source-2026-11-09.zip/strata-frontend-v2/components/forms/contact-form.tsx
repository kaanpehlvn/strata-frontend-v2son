'use client'

import { useState, type FormEvent } from 'react'
import { Check } from 'lucide-react'
import { emailPattern, Field, SelectInput, TextArea, TextInput } from '@/components/forms/fields'

const topics = ['Genel soru', 'Sponsorluk ve iş birliği', 'Etkinlik', 'Basın ve medya', 'Diğer']

type Errors = Partial<Record<'name' | 'email' | 'topic' | 'message', string>>

export function ContactForm() {
  const [errors, setErrors] = useState<Errors>({})
  const [sent, setSent] = useState(false)

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const data = new FormData(e.currentTarget)
    const next: Errors = {}
    const name = String(data.get('name') ?? '').trim()
    const email = String(data.get('email') ?? '').trim()
    const topic = String(data.get('topic') ?? '')
    const message = String(data.get('message') ?? '').trim()

    if (name.length < 2) next.name = 'Lütfen adınızı ve soyadınızı yazın.'
    if (!emailPattern.test(email)) next.email = 'Geçerli bir e-posta adresi girin.'
    if (!topic) next.topic = 'Bir konu seçin.'
    if (message.length < 10) next.message = 'Mesajınız en az 10 karakter olmalı.'

    setErrors(next)
    if (Object.keys(next).length === 0) setSent(true)
  }

  if (sent) {
    return (
      <div role="status" className="border border-ink/20 p-8 md:p-12">
        <span className="flex size-12 items-center justify-center bg-signal text-paper">
          <Check aria-hidden="true" className="size-6" />
        </span>
        <h3 className="display mt-8 text-3xl md:text-4xl">Mesajınız hazır.</h3>
        <p className="mt-4 max-w-md text-pretty leading-relaxed text-ink/70">
          Bu sitedeki form örnek amaçlıdır; mesajınız herhangi bir yere iletilmedi. Gerçek bir iletişim için
          sayfadaki e-posta adresini kullanabilirsiniz.
        </p>
        <button
          type="button"
          onClick={() => setSent(false)}
          className="label mt-8 border-b border-current pb-1 hover:text-signal"
        >
          Yeni mesaj yaz
        </button>
      </div>
    )
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2">
        <Field id="name" label="Ad Soyad" required error={errors.name}>
          <TextInput id="name" autoComplete="name" error={errors.name} />
        </Field>
        <Field id="email" label="E-posta" required error={errors.email}>
          <TextInput id="email" type="email" autoComplete="email" error={errors.email} />
        </Field>
      </div>
      <Field id="topic" label="Konu" required error={errors.topic}>
        <SelectInput id="topic" defaultValue="" error={errors.topic}>
          <option value="" disabled>
            Seçin
          </option>
          {topics.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </SelectInput>
      </Field>
      <Field id="message" label="Mesajınız" required error={errors.message}>
        <TextArea id="message" error={errors.message} />
      </Field>
      <button
        type="submit"
        className="inline-flex h-12 items-center bg-ink px-8 text-sm font-semibold uppercase tracking-[0.14em] text-paper transition-colors duration-300 hover:bg-signal"
      >
        Mesajı gönder
      </button>
    </form>
  )
}
