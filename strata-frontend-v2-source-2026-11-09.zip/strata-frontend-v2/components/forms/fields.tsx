import type { ComponentProps, ReactNode } from 'react'
import { cn } from '@/lib/utils'

const control =
  'w-full border border-ink/25 bg-transparent px-4 text-base text-ink placeholder:text-ink/40 transition-colors duration-300 hover:border-ink/60 focus:border-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink aria-[invalid=true]:border-signal'

export function Field({
  id,
  label,
  error,
  hint,
  required,
  children,
  className,
}: {
  id: string
  label: string
  error?: string
  hint?: string
  required?: boolean
  children: ReactNode
  className?: string
}) {
  return (
    <div className={className}>
      <label htmlFor={id} className="label mb-2 block text-ink/70">
        {label}
        {required ? (
          <span aria-hidden="true" className="ml-1 text-signal">
            *
          </span>
        ) : null}
      </label>
      {children}
      {hint && !error ? (
        <p id={`${id}-hint`} className="mt-2 text-sm text-ink/55">
          {hint}
        </p>
      ) : null}
      {error ? (
        <p id={`${id}-error`} role="alert" className="mt-2 text-sm font-medium text-signal">
          {error}
        </p>
      ) : null}
    </div>
  )
}

function describedBy(id: string, error?: string, hint?: string) {
  if (error) return `${id}-error`
  if (hint) return `${id}-hint`
  return undefined
}

export function TextInput({
  id,
  error,
  hint,
  className,
  ...props
}: ComponentProps<'input'> & { id: string; error?: string; hint?: string }) {
  return (
    <input
      id={id}
      name={id}
      aria-invalid={error ? true : undefined}
      aria-describedby={describedBy(id, error, hint)}
      className={cn(control, 'h-12', className)}
      {...props}
    />
  )
}

export function TextArea({
  id,
  error,
  hint,
  className,
  ...props
}: ComponentProps<'textarea'> & { id: string; error?: string; hint?: string }) {
  return (
    <textarea
      id={id}
      name={id}
      aria-invalid={error ? true : undefined}
      aria-describedby={describedBy(id, error, hint)}
      className={cn(control, 'min-h-36 resize-y py-3', className)}
      {...props}
    />
  )
}

export function SelectInput({
  id,
  error,
  hint,
  className,
  children,
  ...props
}: ComponentProps<'select'> & { id: string; error?: string; hint?: string }) {
  return (
    <select
      id={id}
      name={id}
      aria-invalid={error ? true : undefined}
      aria-describedby={describedBy(id, error, hint)}
      className={cn(control, 'h-12 appearance-none bg-no-repeat pr-10', className)}
      {...props}
    >
      {children}
    </select>
  )
}

export const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
