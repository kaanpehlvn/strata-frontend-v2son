'use client'

import { useState, type FormEvent } from 'react'
import { Field, TextInput } from '@/components/forms/fields'
import {
  applicationStages,
  demoApplications,
  findDemoApplication,
  type DemoApplication,
} from '@/lib/data/applications'
import { cn, formatDate } from '@/lib/utils'

type Result = { kind: 'found'; application: DemoApplication } | { kind: 'missing' } | null

export function StatusLookup() {
  const [studentNumber, setStudentNumber] = useState('')
  const [error, setError] = useState<string>()
  const [result, setResult] = useState<Result>(null)

  function lookup(value: string) {
    const trimmed = value.trim().replace(/\s+/g, '')
    if (!trimmed) {
      setError('Lütfen öğrenci numaranızı girin.')
      setResult(null)
      return
    }
    if (!/^\d{10}$/.test(trimmed)) {
      setError('10 haneli öğrenci numaranızı girin.')
      setResult(null)
      return
    }
    setError(undefined)
    const application = findDemoApplication(trimmed)
    setResult(application ? { kind: 'found', application } : { kind: 'missing' })
  }

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    lookup(studentNumber)
  }

  return (
    <div>
      <form onSubmit={onSubmit} noValidate className="flex flex-col gap-4 sm:flex-row sm:items-end">
        <Field id="student-number" label="Öğrenci numarası" error={error} className="flex-1">
          <TextInput
            id="student-number"
            value={studentNumber}
            onChange={(e) => setStudentNumber(e.target.value.replace(/\D/g, '').slice(0, 10))}
            placeholder="2026123456"
            autoComplete="off"
            inputMode="numeric"
            pattern="[0-9]{10}"
            maxLength={10}
            spellCheck={false}
            error={error}
            className="font-sans tracking-[0.12em]"
          />
        </Field>
        <button
          type="submit"
          className="inline-flex h-12 items-center justify-center bg-ink px-8 text-sm font-semibold uppercase tracking-[0.14em] text-paper transition-colors duration-300 hover:bg-signal focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink"
        >
          Sorgula
        </button>
      </form>

      <div className="mt-6">
        <p className="label text-ink/50">Örnek öğrenci numaraları</p>
        <ul className="mt-3 flex flex-wrap gap-2">
          {demoApplications.map((application) => (
            <li key={application.studentNumber}>
              <button
                type="button"
                onClick={() => {
                  setStudentNumber(application.studentNumber)
                  lookup(application.studentNumber)
                }}
                className="label border border-ink/25 px-3 py-2 text-ink/75 transition-colors hover:border-ink hover:text-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink"
              >
                {application.studentNumber}
              </button>
            </li>
          ))}
        </ul>
      </div>

      <div aria-live="polite" className="mt-12">
        {result?.kind === 'missing' ? (
          <div className="border border-ink/20 p-8">
            <h3 className="display text-2xl">Kayıt bulunamadı.</h3>
            <p className="mt-3 max-w-md text-pretty text-ink/70">
              Bu öğrenci numarasıyla eşleşen bir başvuru bulunamadı. Numaranızı kontrol edin veya yukarıdaki örneklerden birini deneyin.
            </p>
          </div>
        ) : null}

        {result?.kind === 'found' ? <ApplicationResult application={result.application} /> : null}
      </div>
    </div>
  )
}

function ApplicationResult({ application: a }: { application: DemoApplication }) {
  return (
    <article className="border border-ink/20">
      <header className="flex flex-col gap-4 border-b border-ink/20 p-6 md:flex-row md:items-start md:justify-between md:p-8">
        <div>
          <p className="label text-ink/50">Öğrenci numarası: {a.studentNumber}</p>
          <h3 className="display mt-2 text-3xl md:text-4xl">{a.outcome}</h3>
          <p className="label mt-2 text-ink/50">
            Başvuru tarihi: {formatDate(a.appliedAt, { day: 'numeric', month: 'long', year: 'numeric' })}
          </p>
        </div>
        <span
          className={cn(
            'label self-start px-3 py-2',
            a.eliminated && 'bg-red-700 text-paper',
            !a.eliminated && a.outcome === 'Kabul Edildi' && 'bg-ink text-paper',
            !a.eliminated && a.outcome === 'Olumsuz Sonuçlandı' && 'border border-ink/40 text-ink/70',
            !a.eliminated && (a.outcome === 'İnceleniyor' || a.outcome === 'Görüşmeye Davet Edildi') && 'bg-signal text-paper',
          )}
        >
          {a.eliminated ? 'Elendi' : a.stageTitle}
        </span>
      </header>

      <ol className="grid divide-y divide-ink/15 md:grid-cols-4 md:divide-x md:divide-y-0">
        {applicationStages.map((stage, i) => {
          const reached = i <= a.currentStage
          const current = i === a.currentStage
          const date = a.stageDates[i]
          return (
            <li
              key={stage.key}
              aria-current={current ? 'step' : undefined}
              className={cn('p-5', current && 'bg-ink text-paper')}
            >
              <p className="label flex items-center gap-2">
                <span
                  aria-hidden="true"
                  className={cn(
                    'size-2',
                    reached ? (current ? 'bg-signal' : 'bg-ink') : 'border border-current opacity-40',
                  )}
                />
                {String(i + 1).padStart(2, '0')}
              </p>
              {a.eliminated && current ? (
                <span className="label mt-4 inline-flex bg-red-700 px-2 py-1 text-paper">Elendi</span>
              ) : null}
              <p className={cn('mt-4 font-semibold leading-tight', !reached && 'text-ink/40', a.eliminated && current && 'mt-3')}>{stage.label}</p>
              <p className={cn('label mt-2', current ? 'text-paper/60' : 'text-ink/50')}>
                {date ? formatDate(date, { day: 'numeric', month: 'short' }) : reached ? 'Atlandı' : 'Bekleniyor'}
              </p>
            </li>
          )
        })}
      </ol>

      <div className="grid gap-8 border-t border-ink/20 p-6 md:grid-cols-2 md:p-8">
        <div>
          <p className="label text-ink/50">Durum özeti</p>
          <p className="mt-3 text-pretty leading-relaxed">{a.summary}</p>
        </div>
        <div>
          <p className="label text-ink/50">Sonraki adım</p>
          <p className="mt-3 text-pretty leading-relaxed">{a.nextStep}</p>
        </div>
      </div>
    </article>
  )
}
