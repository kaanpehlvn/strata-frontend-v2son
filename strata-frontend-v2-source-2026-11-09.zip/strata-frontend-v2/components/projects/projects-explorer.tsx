import { publicProjects } from '@/lib/data/public-project'

export function ProjectsExplorer() {
  return (
    <ul className="divide-y divide-paper/15 border-y border-paper/15">
      {publicProjects.map((project, index) => (
        <li key={project.name} className="grid gap-6 py-10 md:grid-cols-[5rem_14rem_1fr] md:gap-10 md:py-14">
          <span className="technical text-text-muted-dark">{String(index + 1).padStart(2, '0')}</span>
          <p className="technical text-text-muted-dark">{project.category}</p>
          <div>
            <h2 className="display text-[clamp(2.25rem,5vw,4.75rem)] uppercase leading-[0.9] tracking-[-0.06em]">
              {project.name}
            </h2>
            <p className="mt-6 max-w-2xl text-pretty text-lg leading-relaxed text-paper/70">
              {project.summary}
            </p>
          </div>
        </li>
      ))}
    </ul>
  )
}
