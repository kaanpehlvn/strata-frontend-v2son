import { ArrowUpRight } from 'lucide-react'
import { cn } from '@/lib/utils'

export function WorkspaceButton({ className }: Readonly<{ className?: string }>) {
  return (
    <a
      href="https://workspace.deustrata.com.tr"
      className={cn(
        'group relative inline-flex h-10 items-center gap-2 overflow-hidden border border-paper/30 whitespace-nowrap px-5 text-[0.75rem] font-semibold uppercase tracking-[0.14em] text-paper transition-colors duration-300 hover:border-paper hover:bg-paper hover:text-ink',
        className,
      )}
    >
      <span>WORKSPACE</span>
      <ArrowUpRight
        aria-hidden="true"
        className="size-4 shrink-0 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5"
      />
    </a>
  )
}
