import type { SVGProps } from 'react'

type IconProps = Readonly<SVGProps<SVGSVGElement>>

export function InstagramIcon(props: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true" {...props}>
      <rect x="3" y="3" width="18" height="18" rx="5" stroke="currentColor" strokeWidth="1.8" />
      <circle cx="12" cy="12" r="4" stroke="currentColor" strokeWidth="1.8" />
      <circle cx="17.4" cy="6.6" r="1" fill="currentColor" />
    </svg>
  )
}

export function LinkedinIcon(props: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...props}>
      <path d="M5.1 7.2A2.1 2.1 0 1 0 5.1 3a2.1 2.1 0 0 0 0 4.2ZM3.3 21h3.6V8.7H3.3V21Zm5.8-12.3h3.4v1.7h.1c.5-1 1.7-2.1 3.7-2.1 3.8 0 4.5 2.5 4.5 5.8V21h-3.6v-6.1c0-1.5 0-3.5-2.1-3.5s-2.4 1.6-2.4 3.4V21H9.1V8.7Z" />
    </svg>
  )
}

export function XIcon(props: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...props}>
      <path d="M18.9 2.5h3.7l-8.1 9.3 9.5 9.7h-7.4l-5.8-6-5.3 6H1.8l7.8-8.9L.5 2.5h7.6l5.2 5.5 5.6-5.5Zm-1.3 17.3h2L6.9 4.1H4.7l12.9 15.7Z" />
    </svg>
  )
}
