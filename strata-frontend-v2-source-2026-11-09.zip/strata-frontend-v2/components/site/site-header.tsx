'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useCallback, useEffect, useRef, useState } from 'react'
import { Logo } from '@/components/site/logo'
import { MobileMenu } from '@/components/site/mobile-menu'
import { WorkspaceButton } from '@/components/workspace/workspace-button'
import { joinCta, primaryNav } from '@/lib/data/site'
import { cn } from '@/lib/utils'

export function SiteHeader() {
  const pathname = usePathname()
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const menuButtonRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    setOpen(false)
  }, [pathname])

  useEffect(() => {
    const desktopQuery = window.matchMedia('(min-width: 1440px)')
    const closeOnDesktop = () => {
      if (desktopQuery.matches) setOpen(false)
    }

    closeOnDesktop()
    desktopQuery.addEventListener('change', closeOnDesktop)
    return () => desktopQuery.removeEventListener('change', closeOnDesktop)
  }, [])

  const isActive = (href: string) => pathname === href || pathname.startsWith(`${href}/`)
  const navItems = primaryNav
  const closeMenu = useCallback(() => setOpen(false), [])

  return (
    <header className="fixed inset-x-0 top-0 z-50">
      <div
        aria-hidden="true"
        className={cn(
          'pointer-events-none absolute inset-x-0 top-0 z-10 h-[4.5rem] border-b border-white/10 bg-brand-black/95 transition-[border-color] duration-500',
          scrolled || open ? 'border-paper/15' : 'border-white/10',
        )}
      />
      <div className="container-x relative z-20 flex h-[4.5rem] items-center justify-between gap-8">
        <Logo />

        <nav aria-label="Ana gezinme" className="hidden min-[1440px]:block">
          <ul className="flex items-center gap-5 2xl:gap-7">
            {navItems.map((item) => (
              <li key={item.href}>
                <Link
                  href={item.href}
                  aria-current={isActive(item.href) ? 'page' : undefined}
                  className={cn(
                    'relative whitespace-nowrap py-2 text-[0.75rem] font-medium uppercase tracking-[0.1em] transition-colors duration-300 hover:text-paper 2xl:text-[0.8125rem]',
                    'after:absolute after:inset-x-0 after:-bottom-px after:h-px after:origin-left after:scale-x-0 after:bg-signal after:transition-transform after:duration-500 hover:after:scale-x-100',
                    isActive(item.href)
                      ? 'text-paper after:scale-x-100'
                      : 'text-paper/65',
                  )}
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex items-center gap-3">
          <Link
            href={joinCta.href}
            className="hidden h-10 items-center whitespace-nowrap bg-signal px-5 text-[0.75rem] font-semibold uppercase tracking-[0.14em] text-paper transition-colors duration-300 hover:bg-paper hover:text-ink md:inline-flex"
          >
            {joinCta.label}
          </Link>
          <WorkspaceButton className="hidden min-[1440px]:inline-flex" />

          <button
            ref={menuButtonRef}
            type="button"
            aria-expanded={open}
            aria-controls="mobil-menu"
            aria-label={open ? "Menüyü kapat" : "Menüyü aç"}
            onClick={() => setOpen((wasOpen) => !wasOpen)}
            className="relative z-30 flex size-11 touch-manipulation select-none items-center justify-center min-[1440px]:hidden"
          >
            <span
              aria-hidden="true"
              className={cn(
                'absolute h-px w-6 bg-paper transition-transform duration-500 ease-out-expo',
                '-translate-y-1.5',
              )}
            />
            <span
              aria-hidden="true"
              className={cn(
                'absolute h-px w-6 bg-paper transition-transform duration-500 ease-out-expo',
                'translate-y-1.5',
              )}
            />
          </button>
        </div>
      </div>

      <MobileMenu
        open={open}
        onClose={closeMenu}
        triggerRef={menuButtonRef}
        isActive={isActive}
      />
    </header>
  )
}
