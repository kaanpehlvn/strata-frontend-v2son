'use client'

import Link from 'next/link'
import Image from 'next/image'
import { usePathname } from 'next/navigation'
import { OfficialLogo } from '@/components/site/logo'
import { SocialLinks } from '@/components/site/social-links'
import { joinCta, primaryNav, siteConfig } from '@/lib/data/site'

export function SiteFooter() {
  const pathname = usePathname()
  const footerNav = primaryNav

  return (
    <footer className="relative overflow-hidden border-t border-paper/10 bg-ink">
      <div className="container-x pt-20 md:pt-28">
        <div className="grid gap-14 md:grid-cols-12">
          <div className="md:col-span-5">
            <p className="display text-[clamp(2.25rem,5vw,4rem)] text-balance">
              Bir sonraki
              <br />
              <span className="text-signal">katman</span> sensin.
            </p>
            <p className="mt-6 max-w-sm text-pretty leading-relaxed text-paper/65">
              Merakını ekibe getir. Birlikte araştıralım, deneyelim ve üretelim.
            </p>
            <Link
              href={joinCta.href}
              className="mt-8 inline-flex h-12 items-center bg-signal px-6 text-sm font-semibold uppercase tracking-[0.14em] text-paper transition-colors duration-300 hover:bg-paper hover:text-ink"
            >
              {joinCta.label}
            </Link>
          </div>

          <nav aria-label="Alt gezinme" className="md:col-span-3 md:col-start-7">
            
            <ul className="space-y-3">
              {footerNav.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="text-paper/80 transition-colors duration-300 hover:text-signal"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
              <li>
                <Link
                  href={joinCta.href}
                  className="text-paper/80 transition-colors duration-300 hover:text-signal"
                >
                  {joinCta.label}
                </Link>
              </li>
            </ul>
          </nav>

          <div className="md:col-span-3">
            <p className="label mb-5 text-text-muted-dark">İletişim</p>
            <address className="space-y-3 not-italic text-paper/80">
              <p>
                <a
                  href={`mailto:${siteConfig.email}`}
                  className="transition-colors duration-300 hover:text-signal"
                >
                  {siteConfig.email}
                </a>
              </p>
              <p className="text-pretty text-paper/65">{siteConfig.address}</p>
            </address>
            <div className="mt-6">
              <SocialLinks dark />
            </div>
          </div>
        </div>

        <div aria-hidden="true" className="mt-20 overflow-hidden border-b border-paper/10 pb-8">
          <Image
            src="/strata-logo.jpg"
            alt=""
            width={948}
            height={164}
            className="h-auto w-full object-contain opacity-[0.08]"
          />
        </div>

        <div className="flex flex-col gap-4 border-t border-paper/10 py-8 md:flex-row md:items-center md:justify-between">
          <p className="flex items-center gap-3 text-sm text-paper/55">
            <OfficialLogo alt="" className="h-6 w-auto opacity-80" />
            <span>
              © 2026 {siteConfig.name} · {siteConfig.fullName}
            </span>
          </p>
          {pathname !== '/iletisim' ? (
            <p className="label max-w-xl text-text-muted-dark md:text-right">{siteConfig.tagline}</p>
          ) : null}
        </div>
      </div>
    </footer>
  )
}
