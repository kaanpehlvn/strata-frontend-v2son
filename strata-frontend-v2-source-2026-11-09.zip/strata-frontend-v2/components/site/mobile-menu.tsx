'use client'

import Link from 'next/link'
import { useEffect, useRef } from 'react'
import type { RefObject } from 'react'
import { Logo } from '@/components/site/logo'
import { WorkspaceButton } from '@/components/workspace/workspace-button'
import { joinCta, primaryNav, siteConfig } from '@/lib/data/site'
import { cn } from '@/lib/utils'

type Props = Readonly<{
  open: boolean
  onClose: () => void
  triggerRef: RefObject<HTMLButtonElement | null>
  isActive: (href: string) => boolean
}>

export function MobileMenu({ open, onClose, triggerRef, isActive }: Props) {
  const navItems = [{ label: 'Ana Sayfa', href: '/' }, ...primaryNav]
  const menuRef = useRef<HTMLDialogElement>(null)

  useEffect(() => {
    const menu = menuRef.current
    if (!menu) return

    if (open && !menu.open) menu.showModal()
    if (!open && menu.open) menu.close()
    if (!open) return

    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'

    const frame = window.requestAnimationFrame(() => {
      menu.querySelector<HTMLButtonElement>('[data-menu-close]')?.focus()
    })

    return () => {
      window.cancelAnimationFrame(frame)
      if (menu.open) menu.close()
      document.body.style.overflow = previousOverflow
      triggerRef.current?.focus()
    }
  }, [open, onClose, triggerRef])

  return (
    <dialog
      id="mobil-menu"
      ref={menuRef}
      aria-label="Mobil menü"
      onClose={onClose}
      onCancel={(event) => {
        event.preventDefault()
        onClose()
      }}
      onClick={(event) => {
        if (event.target === menuRef.current) onClose()
      }}
      className="fixed inset-0 m-0 h-dvh max-h-dvh w-full max-w-none overscroll-contain overflow-y-auto border-0 bg-ink p-0 text-paper backdrop:bg-ink/40 min-[1440px]:hidden"
    >
      <div className="container-x flex h-[4.5rem] items-center justify-between border-b border-paper/15">
        <Logo />
        <button
          data-menu-close
          type="button"
          onClick={onClose}
          aria-label="Menüyü kapat"
          className="relative z-10 flex size-11 touch-manipulation items-center justify-center focus-visible:outline-2 focus-visible:outline-offset-[-4px]"
        >
          <span aria-hidden="true" className="absolute h-px w-6 rotate-45 bg-paper" />
          <span aria-hidden="true" className="absolute h-px w-6 -rotate-45 bg-paper" />
        </button>
      </div>
      <nav aria-label="Mobil gezinme" className="container-x flex min-h-[calc(100dvh-4.5rem)] flex-col py-8 pb-[calc(2rem+env(safe-area-inset-bottom))]">
        <ul className="flex flex-col">
          {navItems.map((item, i) => {
            const itemIsActive = item.href !== '/' && isActive(item.href)

            return (
              <li key={item.href} className="border-b border-paper/10">
              <Link
                href={item.href}
                onClick={onClose}
                aria-current={itemIsActive ? 'page' : undefined}
                className={cn(
                  'flex min-w-0 touch-manipulation items-baseline justify-between gap-4 py-4 text-[clamp(2rem,9vw,3rem)] font-extrabold uppercase leading-none [font-stretch:75%]',
                  itemIsActive ? 'text-steel' : 'text-paper',
                )}
              >
                <span className="min-w-0 break-words">{item.label}</span>
                <span className="label shrink-0 text-text-muted-dark">{String(i + 1).padStart(2, '0')}</span>
              </Link>
              </li>
            )
          })}
        </ul>

        <div className="mt-10 flex flex-col gap-3">
          <Link
            href={joinCta.href}
            onClick={onClose}
            className="inline-flex h-12 items-center justify-center bg-signal px-6 text-sm font-semibold uppercase tracking-[0.14em] text-paper"
          >
            {joinCta.label}
          </Link>
          <WorkspaceButton className="h-12 w-full justify-center" />
        </div>

        <p className="label mt-auto pt-12 text-text-muted-dark">
          {siteConfig.university} · {siteConfig.coordinates}
        </p>
      </nav>
    </dialog>
  )
}
