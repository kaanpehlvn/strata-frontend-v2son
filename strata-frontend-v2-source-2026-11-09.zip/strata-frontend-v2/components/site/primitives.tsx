import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import type { ReactNode } from 'react'
import { cn } from '@/lib/utils'

export function SectionLabel({
  index,
  children,
  className,
}: Readonly<{
  index?: string
  children: ReactNode
  className?: string
}>) {
  return (
    <p className={cn('label flex items-center gap-3', className)}>
      <span aria-hidden="true" className="inline-block h-2 w-2 bg-signal" />
      {index ? <span className="opacity-60">{index}</span> : null}
      <span>{children}</span>
    </p>
  )
}

type ButtonLinkProps = {
  href: string
  children: ReactNode
  variant?: 'primary' | 'outline' | 'light' | 'ghost'
  className?: string
  arrow?: boolean
}

const variants = {
  primary: 'bg-signal text-paper hover:bg-paper hover:text-ink',
  outline: 'border border-paper/30 text-paper hover:border-paper hover:bg-paper hover:text-ink',
  light: 'bg-paper text-ink hover:bg-signal hover:text-paper',
  ghost: 'border border-ink/25 text-ink hover:border-ink hover:bg-ink hover:text-paper',
}

export function ButtonLink({
  href,
  children,
  variant = 'primary',
  className,
  arrow = true,
}: Readonly<ButtonLinkProps>) {
  return (
    <Link
      href={href}
      className={cn(
        'group inline-flex h-12 items-center gap-3 px-6 text-sm font-semibold uppercase tracking-[0.14em] transition-colors duration-300',
        variants[variant],
        className,
      )}
    >
      <span>{children}</span>
      {arrow ? (
        <ArrowRight
          aria-hidden="true"
          className="size-4 transition-transform duration-300 group-hover:translate-x-1"
        />
      ) : null}
    </Link>
  )
}

export function TextLink({
  href,
  children,
  className,
}: Readonly<{
  href: string
  children: ReactNode
  className?: string
}>) {
  return (
    <Link
      href={href}
      className={cn(
        'group inline-flex items-center gap-2 border-b border-current pb-1 text-sm font-semibold uppercase tracking-[0.14em]',
        className,
      )}
    >
      {children}
      <ArrowRight
        aria-hidden="true"
        className="size-4 transition-transform duration-300 group-hover:translate-x-1"
      />
    </Link>
  )
}

export function PageHero({
  label,
  title,
  intro,
  children,
}: Readonly<{
  label: string
  title: ReactNode
  intro?: string
  children?: ReactNode
}>) {
  return (
    <section className="relative border-b border-paper/10 pb-16 pt-36 md:pb-24 md:pt-48">
      <div className="container-x">
        <SectionLabel className="text-paper/70">{label}</SectionLabel>
        <h1 className="display mt-8 max-w-4xl text-balance text-[clamp(2.25rem,8vw,7.5rem)]">
          {title}
        </h1>
        {intro ? (
          <p className="mt-10 max-w-2xl text-pretty text-lg leading-relaxed text-paper/70 md:text-xl">
            {intro}
          </p>
        ) : null}
        {children}
      </div>
    </section>
  )
}

export function DemoNote({ children, className }: Readonly<{ children: ReactNode; className?: string }>) {
  return (
    <p
      className={cn(
        'label flex items-start gap-3 border border-dashed border-current/30 px-4 py-3 opacity-80',
        className,
      )}
    >
      <span aria-hidden="true" className="mt-1 inline-block size-1.5 shrink-0 bg-signal" />
      <span className="normal-case tracking-normal">{children}</span>
    </p>
  )
}
