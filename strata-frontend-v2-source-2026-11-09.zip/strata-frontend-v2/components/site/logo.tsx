import Image from 'next/image'
import Link from 'next/link'
import { cn } from '@/lib/utils'

export function OfficialLogo({
  className,
  alt = 'STRATA',
  priority = false,
}: {
  className?: string
  alt?: string
  priority?: boolean
}) {
  return (
    <Image
      src="/images/strata-transparent-logo.png"
      alt={alt}
      width={2172}
      height={724}
      priority={priority}
      className={cn('block h-auto w-[10rem] object-contain sm:w-[11.5rem]', className)}
    />
  )
}

export function Logo({
  className,
  href = '/',
  ariaLabel = 'STRATA — Ana sayfa',
}: {
  className?: string
  href?: string
  ariaLabel?: string
}) {
  return (
    <Link
      href={href}
      aria-label={ariaLabel}
      className={cn('group inline-flex items-center', className)}
    >
      <OfficialLogo
        alt="STRATA"
        priority
        className="transition-transform duration-500 group-hover:-translate-y-px"
      />
    </Link>
  )
}
