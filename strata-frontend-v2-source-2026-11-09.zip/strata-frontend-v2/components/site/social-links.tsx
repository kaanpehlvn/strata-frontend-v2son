import { InstagramIcon, LinkedinIcon, XIcon } from '@/components/contact/social-icons'
import { socialLinks } from '@/lib/data/site'

const platforms = [
  { label: 'Instagram', icon: InstagramIcon },
  { label: 'LinkedIn', icon: LinkedinIcon },
  { label: 'X', icon: XIcon },
] as const

function externalUrl(value: string | undefined) {
  return value && /^https?:\/\//i.test(value) ? value : undefined
}

export function SocialLinks({ dark = false }: Readonly<{ dark?: boolean }>) {
  return (
    <div className="flex gap-2">
      {platforms.map(({ label, icon: Icon }) => {
        const record = socialLinks.find((item) => item.label === label)
        const href = externalUrl(record?.href)
        const labelText = href ? `${label} hesabını aç` : `${label} bağlantısı henüz eklenmedi`
        const enabledClass = dark
          ? 'border-paper/20 text-paper/80 hover:border-paper hover:bg-paper hover:text-ink'
          : 'border-ink/20 text-ink hover:border-ink hover:bg-ink hover:text-paper'
        const disabledClass = dark
          ? 'border-paper/15 text-paper/35'
          : 'border-ink/20 text-ink/35'

        return href ? (
          <a
            key={label}
            href={href}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={labelText}
            className={`group flex size-11 items-center justify-center border transition-[background-color,color,border-color,transform] duration-300 hover:-translate-y-1 focus-visible:outline-2 focus-visible:outline-offset-4 ${enabledClass}`}
          >
            <Icon className="size-5" />
          </a>
        ) : (
          <span
            key={label}
            aria-label={labelText}
            aria-disabled="true"
            className={`flex size-11 items-center justify-center border border-dashed ${disabledClass}`}
            title={labelText}
          >
            <Icon className="size-5" />
          </span>
        )
      })}
    </div>
  )
}
