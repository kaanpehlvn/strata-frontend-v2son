export const publicProjects = [
  {
    name: 'Çelik Kubbe Hava Savunma Sistemi',
    category: 'Hava savunma ve robotik',
    summary:
      'Algılama, takip ve karar süreçlerini tek bir sistem fikrinde buluşturan; robotik, elektronik ve yazılımın kesiştiği bir hava savunma projesidir.',
  },
  {
    name: 'Maglev Treni',
    category: 'Ulaşım ve elektromanyetik sistemler',
    summary:
      'Manyetik kaldırma prensibini merkeze alan; hareket, enerji ve kontrol ilişkisini yeniden düşünmeye açan bir ulaşım sistemi projesidir.',
  },
] as const

export const publicProjectContext = {
  code: 'PROJE / BEKLİYOR',
  summaryShort:
    'Bu ge\u00e7ici kay\u0131t; proje ad\u0131, ekip yap\u0131s\u0131 ve teknik kapsam do\u011fruland\u0131\u011f\u0131nda g\u00fcncellenecek.',
  name: 'STRATA proje kaydı',
  category: 'TEKNOFEST — Çelik Kubbe Hava Savunma Sistemi',
  summary:
    'STRATA’nın doğrulanmış tek proje bağlamı budur. Proje adı, ekip yapısı, teknik kapsam, görseller ve gelişim durumu kesinleştiğinde bu kayıt güncellenecektir.',
  status: 'Geçici içerik — doğrulanmayı bekliyor',
  technologies: 'Henüz paylaşılmadı',
} as const
