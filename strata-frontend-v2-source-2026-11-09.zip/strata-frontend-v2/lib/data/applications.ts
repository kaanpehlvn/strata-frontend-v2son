export const applicationStages = [
  { key: 'alindi', label: 'Başvuru Alındı' },
  { key: 'on-inceleme', label: 'Ön İnceleme' },
  { key: 'degerlendirme', label: 'Değerlendirme' },
  { key: 'gorusme', label: 'Görüşme Aşaması' },
] as const

export type ApplicationOutcome =
  | 'İnceleniyor'
  | 'Görüşmeye Davet Edildi'
  | 'Kabul Edildi'
  | 'Olumsuz Sonuçlandı'

export type DemoApplication = {
  reference: string
  studentNumber: string
  appliedAt: string
  outcome: ApplicationOutcome
  currentStage: number
  stageTitle: string
  summary: string
  nextStep: string
  stageDates: (string | null)[]
  eliminated?: boolean
}

export const demoApplications: DemoApplication[] = [
  {
    reference: 'STR-DEMO-2026-0142',
    studentNumber: '2026123456',
    appliedAt: '2026-10-22',
    outcome: 'İnceleniyor',
    currentStage: 1,
    stageTitle: 'Ön İnceleme',
    summary: 'Başvurunuz eksiksiz alındı ve ön incelemeye alındı.',
    nextStep: 'Ön inceleme tamamlandığında başvurunuz değerlendirme aşamasına geçer. Bu süreçte sizden bir işlem beklenmemektedir.',
    stageDates: ['2026-10-22', '2026-10-24', null, null],
  },
  {
    reference: 'STR-DEMO-2026-0187',
    studentNumber: '2026456789',
    appliedAt: '2026-10-18',
    outcome: 'Görüşmeye Davet Edildi',
    currentStage: 3,
    stageTitle: 'Görüşme Aşaması',
    summary: 'Başvurunuz görüşme için uygun bulundu.',
    nextStep: 'Size iletilecek e-postadaki takvimden bir görüşme saati seçmeniz gerekir. Görüşme yaklaşık 20 dakikadır ve teknik bir sınav içermez.',
    stageDates: ['2026-10-18', '2026-10-20', '2026-10-25', '2026-10-30'],
  },
  {
    reference: 'STR-DEMO-2026-0063',
    studentNumber: '2026012345',
    appliedAt: '2026-10-05',
    outcome: 'Kabul Edildi',
    currentStage: 3,
    stageTitle: 'Görüşme Aşaması',
    summary: 'Başvurunuz olumlu değerlendirildi. STRATA topluluğuna hoş geldiniz.',
    nextStep: 'Uyum oturumu ve topluluk tanışma toplantısı için gerekli bilgiler e-posta ile paylaşılacaktır.',
    stageDates: ['2026-10-05', '2026-10-07', '2026-10-12', '2026-10-19'],
  },
  {
    reference: 'STR-DEMO-2026-0031',
    studentNumber: '2026987654',
    appliedAt: '2026-09-29',
    outcome: 'Olumsuz Sonuçlandı',
    currentStage: 1,
    stageTitle: 'Ön İnceleme',
    summary: 'Başvurunuz ön inceleme aşamasında bu dönem için ilerletilemedi.',
    nextStep: 'Bir sonraki dönemde yeniden başvurabilir, açık günlerimize ve atölyelerimize katılarak toplulukla bağınızı sürdürebilirsiniz.',
    stageDates: ['2026-09-29', '2026-10-01', null, null],
    eliminated: true,
  },
]

export function findDemoApplication(studentNumber: string) {
  const normalized = studentNumber.trim().replace(/\s+/g, '')
  return demoApplications.find((application) => application.studentNumber === normalized)
}
