export type Member = {
  slug: string
  name: string
  initials: string
  role: string
  group: string
  department: string
  year: string
  responsibilities: string[]
  focus: string
  email?: string
  linkedin?: string
}

export type TeamGroup = {
  slug: string
  name: string
  kind: 'Teknik' | 'Organizasyon' | 'Araştırma'
  description: string
  responsibilities: string[]
}

export const teamGroups: TeamGroup[] = [
  {
    slug: 'mekanik',
    name: 'Mekanik Tasarım ve Üretim',
    kind: 'Teknik',
    description:
      'Şasi, mekanizma ve eklem tasarımlarını CAD ortamında kurar; prototiplerin atölyede üretilmesini yönetir.',
    responsibilities: ['CAD ve gerilme analizi', 'Talaşlı ve eklemeli imalat', 'Montaj dokümantasyonu'],
  },
  {
    slug: 'elektronik',
    name: 'Elektronik ve Gömülü Sistemler',
    kind: 'Teknik',
    description:
      'Güç dağıtımı, sürücü kartları ve gömülü yazılım ile robotların elektrik omurgasını oluşturur.',
    responsibilities: ['PCB tasarımı', 'Gömülü yazılım', 'Test ve ölçüm'],
  },
  {
    slug: 'yazilim',
    name: 'Yazılım ve Otonomi',
    kind: 'Teknik',
    description:
      'Konumlandırma, planlama ve kontrol yazılımını geliştirir; simülasyonda doğruladığı kodu sahaya taşır.',
    responsibilities: ['ROS 2 düğümleri', 'Simülasyon', 'Kontrol algoritmaları'],
  },
  {
    slug: 'yapay-zeka',
    name: 'Yapay Zekâ ve Görüntü İşleme',
    kind: 'Teknik',
    description:
      'Veri toplama, model eğitimi ve gömülü çıkarım süreçlerini yürütür; klasik ve öğrenme tabanlı yöntemleri karşılaştırır.',
    responsibilities: ['Veri seti hazırlama', 'Model eğitimi', 'Gömülü çıkarım'],
  },
  {
    slug: 'kurumsal',
    name: 'Sponsorluk ve Kurumsal İlişkiler',
    kind: 'Organizasyon',
    description:
      'Kurum ve kuruluşlarla iletişimi yürütür, destek paketlerini hazırlar ve iş birliklerini düzenli raporlar.',
    responsibilities: ['Sponsor iletişimi', 'Sunum ve rapor', 'Bütçe takibi'],
  },
  {
    slug: 'medya',
    name: 'Medya, Tasarım ve Etkinlik',
    kind: 'Organizasyon',
    description:
      'Topluluğun görsel dilini, sosyal medya akışını ve etkinlik organizasyonlarını üstlenir.',
    responsibilities: ['Grafik tasarım', 'Fotoğraf ve video', 'Etkinlik planlama'],
  },
  {
    slug: 'algilama',
    name: 'Algılama ve Haritalama Okuma Grubu',
    kind: 'Araştırma',
    description:
      'SLAM, sensör birleştirme ve konumlandırma literatürünü haftalık oturumlarla inceleyen araştırma grubu.',
    responsibilities: ['Makale okuma', 'Yöntem karşılaştırma', 'Deney önerileri'],
  },
  {
    slug: 'kontrol',
    name: 'Kontrol Kuramı Çalışma Grubu',
    kind: 'Araştırma',
    description:
      'Geri beslemeli kontrol, durum uzayı ve optimal kontrol konularında ortak çalışma yürüten grup.',
    responsibilities: ['Konu anlatımı', 'Simülasyon çalışmaları', 'Proje danışmanlığı'],
  },
]

export const leadership: Member[] = [
  {
    slug: 'baskan',
    name: 'Ece K.',
    initials: 'EK',
    role: 'Topluluk Başkanı',
    group: 'Yönetim',
    department: 'Makine Mühendisliği',
    year: '4. sınıf',
    responsibilities: ['Topluluk stratejisi', 'Fakülte ve rektörlük ilişkileri', 'Dönem planlaması'],
    focus: 'Mekatronik sistemler',
  },
  {
    slug: 'baskan-yardimcisi',
    name: 'Deniz A.',
    initials: 'DA',
    role: 'Başkan Yardımcısı',
    group: 'Yönetim',
    department: 'Elektrik-Elektronik Mühendisliği',
    year: '4. sınıf',
    responsibilities: ['Ekipler arası koordinasyon', 'Toplantı ve karar takibi', 'Üye gelişim planı'],
    focus: 'Güç elektroniği',
  },
  {
    slug: 'teknik-koordinator',
    name: 'Kerem B.',
    initials: 'KB',
    role: 'Teknik Koordinatör',
    group: 'Yönetim',
    department: 'Bilgisayar Mühendisliği',
    year: '3. sınıf',
    responsibilities: ['Proje portföyü', 'Teknik gözden geçirmeler', 'Mühendislik standartları'],
    focus: 'Robot yazılımı',
  },
  {
    slug: 'idari-koordinator',
    name: 'Selin T.',
    initials: 'ST',
    role: 'İdari Koordinatör',
    group: 'Yönetim',
    department: 'Endüstri Mühendisliği',
    year: '3. sınıf',
    responsibilities: ['Bütçe ve envanter', 'Resmî yazışmalar', 'Laboratuvar düzeni'],
    focus: 'Proje yönetimi',
  },
]

export const members: Member[] = [
  {
    slug: 'mert-o',
    name: 'Mert O.',
    initials: 'MO',
    role: 'Mekanik Ekip Lideri',
    group: 'mekanik',
    department: 'Makine Mühendisliği',
    year: '3. sınıf',
    responsibilities: ['KOL-6 eklem tasarımı', 'Üretim planı'],
    focus: 'Mekanizma tasarımı',
  },
  {
    slug: 'asli-y',
    name: 'Aslı Y.',
    initials: 'AY',
    role: 'Üretim Sorumlusu',
    group: 'mekanik',
    department: 'Metalurji ve Malzeme Mühendisliği',
    year: '2. sınıf',
    responsibilities: ['3B baskı atölyesi', 'Malzeme seçimi'],
    focus: 'Eklemeli imalat',
  },
  {
    slug: 'can-d',
    name: 'Can D.',
    initials: 'CD',
    role: 'Elektronik Ekip Lideri',
    group: 'elektronik',
    department: 'Elektrik-Elektronik Mühendisliği',
    year: '4. sınıf',
    responsibilities: ['SENTEZ kart tasarımı', 'Ölçüm düzeneği'],
    focus: 'Motor sürücüleri',
  },
  {
    slug: 'irem-s',
    name: 'İrem S.',
    initials: 'İS',
    role: 'Gömülü Yazılım Geliştirici',
    group: 'elektronik',
    department: 'Bilgisayar Mühendisliği',
    year: '3. sınıf',
    responsibilities: ['Üretici yazılım', 'CAN Bus protokolü'],
    focus: 'Gerçek zamanlı sistemler',
  },
  {
    slug: 'baris-e',
    name: 'Barış E.',
    initials: 'BE',
    role: 'Yazılım Ekip Lideri',
    group: 'yazilim',
    department: 'Bilgisayar Mühendisliği',
    year: '4. sınıf',
    responsibilities: ['ATLAS navigasyon yığını', 'Simülasyon altyapısı'],
    focus: 'Yol planlama',
  },
  {
    slug: 'zeynep-g',
    name: 'Zeynep G.',
    initials: 'ZG',
    role: 'Otonomi Geliştirici',
    group: 'yazilim',
    department: 'Yazılım Mühendisliği',
    year: '2. sınıf',
    responsibilities: ['İZ haritalama', 'Veri kaydı arşivi'],
    focus: 'SLAM',
  },
  {
    slug: 'onur-h',
    name: 'Onur H.',
    initials: 'OH',
    role: 'Yapay Zekâ Ekip Lideri',
    group: 'yapay-zeka',
    department: 'Bilgisayar Mühendisliği',
    year: '4. sınıf',
    responsibilities: ['GÖZCÜ model eğitimi', 'Değerlendirme ölçütleri'],
    focus: 'Bilgisayarlı görü',
  },
  {
    slug: 'melis-c',
    name: 'Melis C.',
    initials: 'MC',
    role: 'Veri ve Etiketleme Sorumlusu',
    group: 'yapay-zeka',
    department: 'İstatistik',
    year: '3. sınıf',
    responsibilities: ['Veri kalitesi', 'Deney kayıtları'],
    focus: 'Veri bilimi',
  },
  {
    slug: 'tuna-r',
    name: 'Tuna R.',
    initials: 'TR',
    role: 'Kurumsal İlişkiler Sorumlusu',
    group: 'kurumsal',
    department: 'İşletme',
    year: '3. sınıf',
    responsibilities: ['Sponsor görüşmeleri', 'Destek paketleri'],
    focus: 'Kurumsal iletişim',
  },
  {
    slug: 'ayse-n',
    name: 'Ayşe N.',
    initials: 'AN',
    role: 'Tasarım ve Medya Sorumlusu',
    group: 'medya',
    department: 'Grafik Tasarım',
    year: '2. sınıf',
    responsibilities: ['Görsel kimlik', 'Etkinlik afişleri'],
    focus: 'Editoryal tasarım',
  },
]

export function groupName(slug: string) {
  return teamGroups.find((g) => g.slug === slug)?.name ?? slug
}
