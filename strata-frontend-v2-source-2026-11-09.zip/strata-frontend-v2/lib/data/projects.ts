export type StageStatus = 'done' | 'active' | 'planned'

export type ProjectStage = {
  name: string
  status: StageStatus
  note: string
}

export type Project = {
  slug: string
  code: string
  name: string
  category: ProjectCategory
  tagline: string
  summary: string
  description: string[]
  technologies: string[]
  specs: { label: string; value: string }[]
  stages: ProjectStage[]
  team: string
  year: string
}

export const projectCategories = [
  'Tümü',
  'Robotik',
  'Otonom Sistemler',
  'Yapay Zekâ',
  'Gömülü Sistemler',
] as const

export type ProjectCategory = Exclude<(typeof projectCategories)[number], 'Tümü'>

export const projects: Project[] = [
  {
    slug: 'atlas',
    code: 'PRJ-01',
    name: 'ATLAS',
    category: 'Otonom Sistemler',
    tagline: 'Düzensiz zeminde görev yapan otonom yer aracı.',
    summary:
      'Dört tekerlekli, lidar destekli bir platform üzerinde yol planlama ve engel kaçınma algoritmalarını sahada deneyen araştırma aracı.',
    description: [
      'ATLAS, otonom navigasyon yığınını gerçek zemin koşullarında denemek için tasarlanan modüler bir araç platformudur. Şasi, değiştirilebilir sensör plakalarıyla yeni deneylere uyum sağlayacak biçimde kurgulanmıştır.',
      'Yazılım tarafında konumlandırma, harita üretimi ve yol planlama ayrı düğümler olarak geliştirilir. Her düğüm önce simülasyonda, ardından açık alan testlerinde doğrulanır.',
      'Amaç bir ürün çıkarmak değil; öğrencilerin algılama, planlama ve kontrol zincirini uçtan uca kurup hatalarını gözlemleyebileceği tekrarlanabilir bir deney düzeneği oluşturmaktır.',
    ],
    technologies: ['ROS 2', 'C++', 'Python', 'Lidar', 'IMU', 'Kalman Filtresi', 'Gazebo'],
    specs: [
      { label: 'Platform', value: '4 tekerlekten tahrik' },
      { label: 'Algılama', value: '2B lidar, IMU, tekerlek enkoderi' },
      { label: 'Hesaplama', value: 'Gömülü Linux bilgisayarı' },
      { label: 'Durum', value: 'Prototip aşaması' },
    ],
    stages: [
      { name: 'Konsept', status: 'done', note: 'Gereksinimler ve platform seçimi' },
      { name: 'Tasarım', status: 'done', note: 'Şasi ve elektrik mimarisi' },
      { name: 'Prototip', status: 'active', note: 'Sürüş ve algılama entegrasyonu' },
      { name: 'Test', status: 'planned', note: 'Açık alan navigasyon denemeleri' },
      { name: 'Olgunlaşma', status: 'planned', note: 'Dokümantasyon ve devir' },
    ],
    team: 'Yazılım ve Otonomi Ekibi',
    year: '2026',
  },
  {
    slug: 'kol-6',
    code: 'PRJ-02',
    name: 'KOL-6',
    category: 'Robotik',
    tagline: 'Öğrenme amaçlı altı eksenli robot kol.',
    summary:
      'Ters kinematik, yörünge planlama ve eklem kontrolünü masa üstünde deneyimlemek için tasarlanan açık kaynak ilhamlı robot kol.',
    description: [
      'KOL-6, robot manipülatörlerin temelini uygulamalı olarak öğrenmek isteyen üyeler için geliştirilen altı eksenli bir robot koldur. Eklemler 3B baskı ve işlenmiş alüminyum parçaların birleşiminden oluşur.',
      'Kontrol yazılımı eklem uzayında konum, hız ve tork sınırlarını ayrı ayrı yönetir. Ters kinematik çözücü önce MATLAB ortamında doğrulanır, sonra gömülü yazılıma taşınır.',
      'Proje, mekanik, elektronik ve yazılım üyelerinin aynı çıktı üzerinde çalışmasını sağlayan bir ortak zemin olarak da kullanılır.',
    ],
    technologies: ['SolidWorks', 'MATLAB', 'C', 'FOC Sürücü', 'CAN Bus', 'FDM Baskı'],
    specs: [
      { label: 'Serbestlik', value: '6 eksen' },
      { label: 'Aktüatör', value: 'Fırçasız motor + dişli kutusu' },
      { label: 'İletişim', value: 'CAN Bus' },
      { label: 'Durum', value: 'Tasarım aşaması' },
    ],
    stages: [
      { name: 'Konsept', status: 'done', note: 'Kinematik yapı belirlendi' },
      { name: 'Tasarım', status: 'active', note: 'Eklem modülleri ve CAD' },
      { name: 'Prototip', status: 'planned', note: 'İlk üç eksenin kurulumu' },
      { name: 'Test', status: 'planned', note: 'Konum doğruluğu ölçümleri' },
      { name: 'Olgunlaşma', status: 'planned', note: 'Eğitim materyali' },
    ],
    team: 'Mekanik Tasarım Ekibi',
    year: '2026',
  },
  {
    slug: 'gozcu',
    code: 'PRJ-03',
    name: 'GÖZCÜ',
    category: 'Yapay Zekâ',
    tagline: 'Görüntü işleme ile parça denetim istasyonu.',
    summary:
      'Bant üzerinden geçen küçük parçaları kamerayla inceleyip kusurları sınıflandıran, düşük maliyetli bir görüntü işleme istasyonu.',
    description: [
      'GÖZCÜ, klasik görüntü işleme ile derin öğrenme yaklaşımlarını aynı problem üzerinde karşılaştırmayı amaçlar. Aynı veri seti hem eşikleme ve kontur analiziyle hem de küçük bir evrişimli ağla değerlendirilir.',
      'Aydınlatma, kamera konumu ve bant hızı gibi fiziksel etkenler de projenin parçasıdır. Üyeler modelin başarısının yalnızca algoritmaya değil, düzenek tasarımına da bağlı olduğunu görür.',
      'Veri toplama, etiketleme ve model değerlendirme adımları belgelenir; böylece deneyler sonradan tekrarlanabilir.',
    ],
    technologies: ['Python', 'OpenCV', 'PyTorch', 'ONNX', 'Jetson', 'Veri Etiketleme'],
    specs: [
      { label: 'Girdi', value: 'Endüstriyel kamera, kontrollü aydınlatma' },
      { label: 'Yöntem', value: 'Klasik görüntü işleme ve CNN' },
      { label: 'Çıkarım', value: 'Gömülü GPU modülü' },
      { label: 'Durum', value: 'Prototip aşaması' },
    ],
    stages: [
      { name: 'Konsept', status: 'done', note: 'Problem tanımı ve veri planı' },
      { name: 'Tasarım', status: 'done', note: 'Düzenek ve aydınlatma tasarımı' },
      { name: 'Prototip', status: 'active', note: 'Veri toplama ve ilk model' },
      { name: 'Test', status: 'planned', note: 'Yöntem karşılaştırması' },
      { name: 'Olgunlaşma', status: 'planned', note: 'Teknik rapor' },
    ],
    team: 'Yapay Zekâ ve Görüntü İşleme Ekibi',
    year: '2026',
  },
  {
    slug: 'dalgic',
    code: 'PRJ-04',
    name: 'DALGIÇ',
    category: 'Otonom Sistemler',
    tagline: 'Havuz testlerine yönelik küçük sualtı aracı.',
    summary:
      'Su geçirmez gövde, itici yerleşimi ve derinlik kontrolünü öğrenmek için tasarlanan uzaktan kumandalı sualtı aracı.',
    description: [
      'DALGIÇ, sızdırmazlık, kaldırma kuvveti ve itici yerleşimi gibi sualtı robotiğine özgü sorunları küçük ölçekte deneyimlemek için başlatıldı.',
      'Araç önce kumandalı olarak çalıştırılır; ardından derinlik ve yön kontrolünü otomatikleştiren geri besleme döngüleri eklenir.',
      'Proje, üretim ve elektronik ekipleri için yalıtım, kablolama ve güvenlik prosedürleri konusunda pratik bir okul işlevi görür.',
    ],
    technologies: ['Fusion 360', 'ArduPilot', 'PID Kontrol', 'Basınç Sensörü', 'Epoksi Kalıp'],
    specs: [
      { label: 'İtici', value: '6 itici, vektörel yerleşim' },
      { label: 'Gövde', value: 'Akrilik tüp, O-ring sızdırmazlık' },
      { label: 'Algılama', value: 'Basınç sensörü, IMU, kamera' },
      { label: 'Durum', value: 'Konsept aşaması' },
    ],
    stages: [
      { name: 'Konsept', status: 'active', note: 'Gövde ve itici yerleşimi' },
      { name: 'Tasarım', status: 'planned', note: 'CAD ve sızdırmazlık hesapları' },
      { name: 'Prototip', status: 'planned', note: 'Kuru montaj' },
      { name: 'Test', status: 'planned', note: 'Havuz denemeleri' },
      { name: 'Olgunlaşma', status: 'planned', note: 'Kullanım kılavuzu' },
    ],
    team: 'Elektronik ve Üretim Ekibi',
    year: '2026',
  },
  {
    slug: 'sentez',
    code: 'PRJ-05',
    name: 'SENTEZ',
    category: 'Gömülü Sistemler',
    tagline: 'Modüler fırçasız motor sürücü kartı.',
    summary:
      'Topluluk projelerinde ortak kullanılabilecek, CAN Bus destekli ve açık donanım olarak belgelenen motor sürücü kartı.',
    description: [
      'SENTEZ, farklı projelerde tekrar tekrar sıfırdan sürücü tasarlama ihtiyacını ortadan kaldırmak için başlatılan bir ortak donanım çalışmasıdır.',
      'Kart; akım ölçümü, sıcaklık izleme ve koruma devreleriyle donatılır. Üretici yazılımı, kart başına benzersiz bir kimlikle CAN Bus üzerinde yönetilebilir.',
      'Şematik, PCB yerleşimi ve test raporları sürümlenerek saklanır. Böylece yeni üyeler kartı hem kullanabilir hem de bir sonraki revizyona katkı verebilir.',
    ],
    technologies: ['KiCad', 'STM32', 'C', 'FOC', 'CAN Bus', 'Osiloskop'],
    specs: [
      { label: 'Denetleyici', value: 'ARM Cortex-M tabanlı MCU' },
      { label: 'Koruma', value: 'Aşırı akım, aşırı ısı, ters polarite' },
      { label: 'Arayüz', value: 'CAN Bus, UART' },
      { label: 'Durum', value: 'Test aşaması' },
    ],
    stages: [
      { name: 'Konsept', status: 'done', note: 'Gereksinim listesi' },
      { name: 'Tasarım', status: 'done', note: 'Şematik ve PCB' },
      { name: 'Prototip', status: 'done', note: 'İlk revizyon kartı' },
      { name: 'Test', status: 'active', note: 'Yük ve ısı ölçümleri' },
      { name: 'Olgunlaşma', status: 'planned', note: 'Revizyon B ve dokümantasyon' },
    ],
    team: 'Elektronik ve Gömülü Sistemler Ekibi',
    year: '2026',
  },
  {
    slug: 'iz',
    code: 'PRJ-06',
    name: 'İZ',
    category: 'Robotik',
    tagline: 'Kapalı alan haritalama robotu.',
    summary:
      'Koridorlarda ilerleyerek lidar verisinden iki boyutlu harita çıkaran, paletli küçük bir araştırma robotu.',
    description: [
      'İZ, eşzamanlı konumlandırma ve haritalama yöntemlerini düşük maliyetli donanımla denemek için tasarlanan paletli bir robottur.',
      'Üyeler farklı SLAM algoritmalarını aynı veri kaydı üzerinde çalıştırıp harita kalitesini karşılaştırır. Kayıtlar gelecekteki üyelerin de kullanabilmesi için arşivlenir.',
      'Robotun küçük boyutu, laboratuvar koridorlarında güvenli ve sık deneme yapılmasına imkân tanır.',
    ],
    technologies: ['ROS 2', 'SLAM Toolbox', 'Lidar', 'Python', 'Raspberry Pi', 'Paletli Şasi'],
    specs: [
      { label: 'Tahrik', value: 'Paletli, diferansiyel sürüş' },
      { label: 'Algılama', value: '2B lidar, IMU' },
      { label: 'Çıktı', value: 'Doluluk ızgara haritası' },
      { label: 'Durum', value: 'Prototip aşaması' },
    ],
    stages: [
      { name: 'Konsept', status: 'done', note: 'Hedef senaryolar' },
      { name: 'Tasarım', status: 'done', note: 'Şasi ve güç sistemi' },
      { name: 'Prototip', status: 'active', note: 'İlk harita kayıtları' },
      { name: 'Test', status: 'planned', note: 'Algoritma karşılaştırması' },
      { name: 'Olgunlaşma', status: 'planned', note: 'Açık veri seti' },
    ],
    team: 'Yazılım ve Otonomi Ekibi',
    year: '2026',
  },
]

export function getProject(slug: string) {
  return projects.find((p) => p.slug === slug)
}
