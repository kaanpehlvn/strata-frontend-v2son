export const siteConfig = {
  name: 'STRATA',
  fullName: 'Stratejik Teknolojiler ve Robotik Ara\u015ft\u0131rma Toplulu\u011fu',
  university: 'Dokuz Eyl\u00fcl \u00dcniversitesi',
  tagline: 'Gelece\u011fi tasarl\u0131yoruz.',
  email: 'admin@deustrata.com.tr',
  address: 'Dokuz Eyl\u00fcl \u00dcniversitesi Fen Fak\u00fcltesi, Buca / \u0130zmir',
  coordinates: '38\u00b022\u2032N \u00b7 27\u00b012\u2032E',
} as const

export type NavItem = { label: string; href: string }

export const primaryNav: NavItem[] = [
  { label: 'Hakk\u0131m\u0131zda', href: '/hakkimizda' },
  { label: 'Projeler', href: '/projeler' },
  { label: '\u0130leti\u015fim', href: '/iletisim' },
  { label: 'Ba\u015fvuru Durumu', href: '/basvuru-durumu' },
].filter((item) => {
  if (item.href === '/projeler') return false
  return true
})

export const joinCta: NavItem = { label: '\u00dcye \u00d6n Kay\u0131t', href: '/uye-on-kayit' }

export const socialLinks = [
  { label: 'Instagram', handle: '@deustrata', href: 'https://www.instagram.com/deustrata/' },
  { label: 'LinkedIn', handle: 'STRATA DEU', href: 'https://www.linkedin.com/groups/40610372/' },
  { label: 'X', handle: '', href: '' },
] as const
