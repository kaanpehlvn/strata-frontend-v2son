import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(iso: string, opts?: Intl.DateTimeFormatOptions) {
  const d = new Date(`${iso}T12:00:00`)
  return d.toLocaleDateString('tr-TR', opts ?? { day: 'numeric', month: 'long', year: 'numeric' })
}
